#!/usr/bin/env python
from __future__ import annotations

import argparse
from collections import Counter
import json
import os
from pathlib import Path
import pickle
import time
from typing import Any

import networkx as nx
import numpy as np
import torch

from grapher.data.io import load_dataset_splits
from grapher.data.sampling import restore_training_graphs
from grapher.models.dhvae_hh.degree_sampler import TypedDegreeVAESampler
from grapher.models.dhvae_hh.typed_constructor import (
    TypedConstructionError,
    construct_typed_graph,
)
from grapher.rewiring_mlp.attributed.spectral_graphlet_refiner import (
    AttributedSpectralGraphletRefinerConfig,
    enrich_attributed_graph_with_invariant_summary,
    refine_attributed_graph_with_spectral_graphlet_diffusion,
)
from grapher.rewiring_mlp.attributed.spectral_model import (
    ATTRIBUTED_SPECTRAL_GRAPHLET_CHECKPOINT_FORMAT,
    load_attributed_spectral_graphlet_checkpoint,
)
from grapher.rewiring_mlp.molecular.constraints import bond_order
from grapher.rewiring_mlp.molecular.graph_io import (
    graph_to_smiles,
    is_valid_molecular_graph,
)
from grapher.rewiring_mlp.molecular.typed_invariants import (
    TypedInvariant,
    attributed_rewiring_invariant_matches_graph,
    extract_attributed_rewiring_invariant,
    extract_typed_invariant,
    typed_invariant_matches_graph,
)
from grapher.utils.io import (
    apply_config_overrides,
    ensure_dir,
    load_yaml,
    save_json,
    save_pickle,
)


def _limited(values: list[Any], limit: int | None) -> list[Any]:
    return values if limit is None or int(limit) <= 0 else values[: int(limit)]


def _generation_rdkit_valid(
    graph: nx.Graph,
    *,
    infer_projected_formal_charges: bool,
) -> bool:
    """Apply the configured generation validity policy without changing raw metrics."""

    return is_valid_molecular_graph(
        graph,
        infer_projected_formal_charges=infer_projected_formal_charges,
    )


def _complete_molecular_aliases(
    graph: nx.Graph,
    *,
    node_attribute: str,
    edge_attribute: str,
) -> nx.Graph:
    """Normalize labels and provide the aliases used by RDKit helpers."""

    out = nx.convert_node_labels_to_integers(
        nx.Graph(graph), first_label=0, ordering="sorted"
    )
    for node, data in out.nodes(data=True):
        if node_attribute not in data:
            raise KeyError(f"Node {node!r} is missing {node_attribute!r}.")
        value = data[node_attribute]
        data.setdefault("atomic_num", int(value))
        data.setdefault("atom_type", int(value))
    for u, v, data in out.edges(data=True):
        if edge_attribute not in data:
            raise KeyError(f"Edge {(u, v)!r} is missing {edge_attribute!r}.")
        value = int(data[edge_attribute])
        data.setdefault("bond_type", value)
        data.setdefault("bond_order", float(bond_order(value)))
    return out


def _atomic_pickle(obj: Any, path: str | Path) -> None:
    path = Path(path)
    ensure_dir(path.parent)
    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("wb") as handle:
        pickle.dump(obj, handle)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)


def _atomic_json(obj: Any, path: str | Path) -> None:
    path = Path(path)
    ensure_dir(path.parent)
    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("w", encoding="utf-8") as handle:
        json.dump(obj, handle, indent=2, sort_keys=True)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)


def _mean(rows: list[dict[str, Any]], key: str) -> float:
    values = [float(row[key]) for row in rows if row.get(key) is not None]
    return float(np.mean(values)) if values else 0.0


def _mean_values(values: list[Any]) -> float:
    return float(np.mean(values)) if values else 0.0


def _weighted_valence(graph: nx.Graph) -> tuple[float, ...]:
    values = {int(node): 0.0 for node in graph.nodes()}
    for u, v, data in graph.edges(data=True):
        category = int(data.get("bond_type", data.get("bond_order", 1)))
        weight = float(bond_order(category))
        values[int(u)] += weight
        values[int(v)] += weight
    return tuple(values[index] for index in sorted(values))


def _edge_type_counts(graph: nx.Graph, edge_attribute: str) -> Counter[Any]:
    return Counter(data[edge_attribute] for _, _, data in graph.edges(data=True))


def _typed_degree_vectors(
    graph: nx.Graph,
    *,
    edge_types: tuple[Any, ...],
    edge_attribute: str,
) -> tuple[tuple[int, ...], ...]:
    edge_index = {value: index for index, value in enumerate(edge_types)}
    counts = [[0 for _ in edge_types] for _ in sorted(graph.nodes())]
    node_index = {node: index for index, node in enumerate(sorted(graph.nodes()))}
    for u, v, data in graph.edges(data=True):
        category = data[edge_attribute]
        column = edge_index[category]
        counts[node_index[u]][column] += 1
        counts[node_index[v]][column] += 1
    return tuple(tuple(int(value) for value in row) for row in counts)


def _preservation_audit(
    source: nx.Graph,
    final: nx.Graph,
    *,
    node_attribute: str,
    edge_attribute: str,
) -> dict[str, bool]:
    source_nodes = tuple(source.nodes[node][node_attribute] for node in sorted(source.nodes()))
    final_nodes = tuple(final.nodes[node][node_attribute] for node in sorted(final.nodes()))
    source_degrees = tuple(int(source.degree(node)) for node in sorted(source.nodes()))
    final_degrees = tuple(int(final.degree(node)) for node in sorted(final.nodes()))
    edge_types = tuple(
        sorted(
            set(_edge_type_counts(source, edge_attribute))
            | set(_edge_type_counts(final, edge_attribute)),
            key=lambda value: repr(value),
        )
    )
    source_typed = _typed_degree_vectors(
        source, edge_types=edge_types, edge_attribute=edge_attribute
    )
    final_typed = _typed_degree_vectors(
        final, edge_types=edge_types, edge_attribute=edge_attribute
    )
    changed_typed_nodes = sum(
        left != right for left, right in zip(source_typed, final_typed)
    )
    return {
        "node_type_preserved": source_nodes == final_nodes,
        "indexed_degree_preserved": source_degrees == final_degrees,
        "edge_type_counts_preserved": _edge_type_counts(
            source, edge_attribute
        )
        == _edge_type_counts(final, edge_attribute),
        "weighted_valence_preserved": bool(
            np.allclose(_weighted_valence(source), _weighted_valence(final), atol=1.0e-8)
        ),
        "typed_degree_preserved": source_typed == final_typed,
        "typed_degree_changed_node_fraction": float(
            changed_typed_nodes / max(len(source_typed), 1)
        ),
    }


def _sample_invariant(
    source_mode: str,
    *,
    index: int,
    train_graphs: list[nx.Graph],
    test_graphs: list[nx.Graph],
    typed_sampler: TypedDegreeVAESampler | None,
    rng: np.random.Generator,
    edge_types: tuple[Any, ...],
    node_attribute: str,
    edge_attribute: str,
) -> tuple[TypedInvariant, dict[str, Any]]:
    if source_mode in {"oracle", "test_oracle"}:
        if not test_graphs:
            raise ValueError("Oracle typed-invariant generation requires a non-empty test split.")
        reference_index = int(index % len(test_graphs))
        graph = test_graphs[reference_index]
        return (
            extract_typed_invariant(
                graph,
                edge_types=edge_types,
                node_attribute=node_attribute,
                edge_attribute=edge_attribute,
            ),
            {"reference_split": "test", "reference_index": reference_index},
        )
    if source_mode in {"empirical", "train_empirical"}:
        if not train_graphs:
            raise ValueError("Empirical typed-invariant generation requires training graphs.")
        reference_index = int(rng.integers(0, len(train_graphs)))
        graph = train_graphs[reference_index]
        return (
            extract_typed_invariant(
                graph,
                edge_types=edge_types,
                node_attribute=node_attribute,
                edge_attribute=edge_attribute,
            ),
            {"reference_split": "train", "reference_index": reference_index},
        )
    if source_mode == "test_empirical":
        if not test_graphs:
            raise ValueError(
                "generation.invariant_source=test_empirical requires a non-empty test split."
            )
        reference_index = int(rng.integers(0, len(test_graphs)))
        graph = test_graphs[reference_index]
        return (
            extract_typed_invariant(
                graph,
                edge_types=edge_types,
                node_attribute=node_attribute,
                edge_attribute=edge_attribute,
            ),
            {"reference_split": "test", "reference_index": reference_index},
        )
    if source_mode in {"learned", "typed_vae", "degree_vae"}:
        if typed_sampler is None:
            raise ValueError("Learned typed-invariant generation requires degree_generator checkpoint_path.")
        summary = typed_sampler.sample(rng)
        invariant = TypedInvariant.from_dict(summary["typed_invariant"])
        return invariant, {"reference_split": None, "reference_index": None}
    raise ValueError(f"Unknown generation.invariant_source: {source_mode!r}")


def _partial_report(
    *,
    generated: int,
    requested: int,
    attempts: list[int],
    started: float,
    skipped_graphs: list[dict[str, Any]] | None = None,
    rejection_reasons: Counter[str] | None = None,
    generated_indices: list[int] | None = None,
    max_total_graph_attempts: int | None = None,
) -> dict[str, Any]:
    total_budget = 10 * requested if max_total_graph_attempts is None else max_total_graph_attempts
    return {
        "format": "attributed_spectral_graphlet_partial_generation_v2",
        "complete": False,
        "generated": int(generated),
        "requested": int(requested),
        "num_requested": int(requested),
        "num_attempted": len(attempts),
        "num_generated": int(generated),
        "num_skipped": len(skipped_graphs or []),
        "skipped_graphs": list(skipped_graphs or []),
        "generated_indices": list(generated_indices or []),
        "requested_count_reached": generated == requested,
        "max_total_graph_attempts": total_budget,
        "replacement_attempts": max(0, len(attempts) - requested),
        "replacement_budget_exhausted": generated < requested and len(attempts) >= total_budget,
        "generation_success_fraction": float(generated / max(len(attempts), 1)),
        "generation_rejections": dict(sorted((rejection_reasons or {}).items())),
        "generation_attempts": int(sum(attempts)),
        "end_to_end_yield_so_far": float(generated / max(sum(attempts), 1)),
        "runtime_seconds": float(time.perf_counter() - started),
    }


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Generate attributed molecular graphs using a typed source initializer, "
            "continuous topology/bond-spectrum and attributed graphlet-logit denoising, "
            "and bond-reassigning degree-constrained rewiring projection."
        )
    )
    parser.add_argument("--config", required=True)
    parser.add_argument("--checkpoint", default=None)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--num-generate", type=int, default=None)
    parser.add_argument("--seed", type=int, default=None)
    parser.add_argument("--device", default=None)
    parser.add_argument(
        "--set",
        "--override",
        dest="config_overrides",
        action="append",
        default=[],
        metavar="KEY=VALUE",
        help="Override a YAML option with a dotted path; repeat as needed.",
    )
    args = parser.parse_args()
    started = time.perf_counter()

    config = load_yaml(args.config)
    apply_config_overrides(config, args.config_overrides)
    if bool((config.get("joint_typed_degree") or {}).get("enabled", False)):
        from grapher.rewiring_mlp.attributed.joint_typed_edge_generation import generate_joint_typed_edge
        generate_joint_typed_edge(config, args)
        return
    stage = str((config.get("pipeline", {}) or {}).get("stage", "attributed")).lower()
    if stage not in {"attributed", "attributed_topology", "molecular"}:
        raise ValueError("run_attributed_grapher.py requires pipeline.stage: attributed.")

    seed = int(args.seed if args.seed is not None else config.get("seed", 0))
    torch.manual_seed(seed)
    seed_sequence = np.random.SeedSequence(seed)
    source_seed, refiner_seed = seed_sequence.spawn(2)
    source_rng = np.random.default_rng(source_seed)

    dataset_cfg = dict(config.get("dataset", {}) or {})
    splits = load_dataset_splits(
        str(dataset_cfg.get("name", "qm9_attributed")),
        root=dataset_cfg.get("root", "outputs/datasets"),
        build_if_missing=bool(dataset_cfg.get("build_if_missing", False)),
        config_path=dataset_cfg.get("config_path"),
    )
    train_graphs = list(splits["train"])
    test_graphs = list(splits.get("test", []))

    predictor_cfg = dict(config.get("attributed_predictor", {}) or {})
    checkpoint_path = args.checkpoint or predictor_cfg.get("checkpoint_path")
    if not checkpoint_path:
        raise ValueError("attributed_predictor.checkpoint_path is required.")
    model, vocabulary, graphlet_basis, summary_config, checkpoint = (
        load_attributed_spectral_graphlet_checkpoint(
            checkpoint_path,
            device=args.device or predictor_cfg.get("device", "auto"),
        )
    )
    if checkpoint.get("format") != ATTRIBUTED_SPECTRAL_GRAPHLET_CHECKPOINT_FORMAT:
        raise ValueError("Unsupported attributed predictor checkpoint format.")
    trained_dataset_cfg = dict((checkpoint.get("config", {}) or {}).get("dataset", {}) or {})
    if trained_dataset_cfg.get("training_subset") is not None:
        train_graphs = restore_training_graphs(train_graphs, trained_dataset_cfg)
    train_graphs = _limited(train_graphs, dataset_cfg.get("max_generation_train_graphs"))
    model_device = next(model.parameters()).device
    node_attribute = str(vocabulary.node_attribute)
    edge_attribute = str(vocabulary.edge_attribute)
    predictor_report = dict(checkpoint.get("report", {}) or {})

    categorical_cfg = dict(config.get("categorical_state", {}) or {})
    configured_nodes = categorical_cfg.get("node_categories")
    configured_edges = categorical_cfg.get("edge_categories")
    if configured_nodes is not None and tuple(configured_nodes) != tuple(vocabulary.node_values):
        raise ValueError(
            f"Configured node categories {tuple(configured_nodes)} do not match checkpoint {vocabulary.node_values}."
        )
    if configured_edges is not None and tuple(configured_edges) != tuple(vocabulary.edge_values):
        raise ValueError(
            f"Configured edge categories {tuple(configured_edges)} do not match checkpoint {vocabulary.edge_values}."
        )

    print(
        "[GraphER/AttributedSpectralGraphlet] loaded joint attributed checkpoint "
        f"format={checkpoint.get('format')} device={model_device}",
        flush=True,
    )
    print(
        "[GraphER/AttributedSpectralGraphlet] training=continuous stochastic summary diffusion "
        "without rewiring; generation=reverse summary target followed by bond-reassigning "
        "degree-constrained discrete rewiring projection.",
        flush=True,
    )
    print(
        "[GraphER/AttributedSpectralGraphlet] guidance channels: unweighted topology spectrum, "
        "bond-order-weighted spectrum, and attributed graphlet CLR/logit diffusion "
        f"(topology_filter={graphlet_basis.topology_filter}, "
        f"orders={','.join(graphlet_basis.sizes)}).",
        flush=True,
    )

    generation_cfg = dict(config.get("generation", {}) or {})
    num_generate = int(
        args.num_generate
        if args.num_generate is not None
        else generation_cfg.get("num_generate", len(test_graphs) or 256)
    )
    if num_generate <= 0:
        raise ValueError("num_generate must be positive.")
    max_total_graph_attempts = generation_cfg.get("max_total_graph_attempts", 10 * num_generate)
    if (isinstance(max_total_graph_attempts, bool)
            or not isinstance(max_total_graph_attempts, (int, np.integer))
            or max_total_graph_attempts < num_generate):
        raise ValueError("generation.max_total_graph_attempts must be an integer >= num_generate.")
    max_total_graph_attempts = int(max_total_graph_attempts)
    max_attempts = int(generation_cfg.get("max_attempts_per_graph", 32))
    if max_attempts < 1:
        raise ValueError("generation.max_attempts_per_graph must be positive.")
    invariant_source = str(
        generation_cfg.get(
            "invariant_source", generation_cfg.get("degree_source", "empirical")
        )
    ).lower()
    require_source_validity = bool(
        generation_cfg.get("require_rdkit_source_validity", False)
    )
    require_final_validity = bool(
        generation_cfg.get("require_rdkit_final_validity", False)
    )
    checkpoint_every = max(int(generation_cfg.get("checkpoint_every", 25)), 0)
    store_traces = bool(generation_cfg.get("store_traces", True))

    typed_sampler: TypedDegreeVAESampler | None = None
    if invariant_source in {"learned", "typed_vae", "degree_vae"}:
        degree_cfg = dict(config.get("degree_generator", {}) or {})
        degree_type = str(degree_cfg.get("type", "typed_degree_histogram_vae")).lower()
        if "typed" not in degree_type:
            raise ValueError("Attributed learned generation requires a typed-degree VAE.")
        typed_sampler = TypedDegreeVAESampler.from_config(degree_cfg, seed=seed)
    elif invariant_source not in {
        "empirical",
        "train_empirical",
        "test_empirical",
        "oracle",
        "test_oracle",
    }:
        raise ValueError(f"Unknown generation.invariant_source: {invariant_source!r}")

    if invariant_source in {"test_empirical", "oracle", "test_oracle"}:
        print(
            "[GraphER/AttributedSpectralGraphlet] held-out typed-invariant diagnostic enabled "
            f"source={invariant_source}; this uses test-set invariant information and must not "
            "be reported as unconditional generation.",
            flush=True,
        )

    constructor_cfg = dict(config.get("constructor", {}) or {})
    constructor_type = str(constructor_cfg.get("type", "typed_backtracking")).lower()
    if constructor_type not in {"typed_backtracking", "typed", "typed_constructor"}:
        raise ValueError("Attributed generation requires constructor.type: typed_backtracking.")
    refiner_cfg = AttributedSpectralGraphletRefinerConfig.from_dict(
        dict(config.get("attributed_refiner", {}) or {})
    )
    source_enrichment_cfg = dict(config.get("source_enrichment", {}) or {})
    source_enrichment_enabled = bool(source_enrichment_cfg.get("enabled", False))
    source_enrichment_refiner: AttributedSpectralGraphletRefinerConfig | None = None
    if source_enrichment_enabled:
        if not bool(getattr(model, "invariant_summary_enabled", False)):
            raise ValueError(
                "source_enrichment.enabled requires a checkpoint trained with "
                "source_enrichment.summary_estimator.enabled: true."
            )
        source_enrichment_refiner = AttributedSpectralGraphletRefinerConfig.from_dict(
            dict(source_enrichment_cfg.get("rewiring", {}) or {})
        )
    print(
        "[GraphER/AttributedSpectralGraphlet] "
        f"debug={refiner_cfg.debug_enabled} steps={refiner_cfg.steps} "
        f"proposal_budget={refiner_cfg.proposal_budget} "
        f"valid_candidate_budget={refiner_cfg.valid_candidate_budget} "
        f"rdkit_shortlist={refiner_cfg.rdkit_shortlist} "
        f"rdkit_validation_mode={refiner_cfg.rdkit_validation_mode} "
        f"rewiring_kernel={'same_edge_type' if refiner_cfg.require_same_edge_type_pair else 'bond_reassigning_cross_type'}",
        flush=True,
    )
    print(
        "[GraphER/AttributedSpectralGraphlet] "
        "cycle_guidance_components="
        f"(clr={refiner_cfg.graphlet_logit_distance_weight:.3f},"
        f"probability={refiner_cfg.graphlet_probability_distance_weight:.3f},"
        f"selected_mass={refiner_cfg.graphlet_selected_mass_weight:.3f}) "
        "chemistry_drift_weights="
        f"(typed_degree={refiner_cfg.typed_degree_drift_weight:.3f},"
        f"weighted_valence={refiner_cfg.weighted_valence_drift_weight:.3f})",
        flush=True,
    )

    if source_enrichment_enabled:
        assert source_enrichment_refiner is not None
        print(
            "[GraphER/AttributedSpectralGraphlet] source_enrichment=hard_invariant_summary "
            f"steps={source_enrichment_refiner.steps} "
            f"proposal_budget={source_enrichment_refiner.proposal_budget} "
            f"valid_candidate_budget={source_enrichment_refiner.valid_candidate_budget}",
            flush=True,
        )

    output_dir = ensure_dir(args.output_dir)
    source_graphs: list[nx.Graph] = []
    enriched_base_graphs: list[nx.Graph] = []
    final_graphs: list[nx.Graph] = []
    enrichment_traces: list[list[dict[str, Any]]] = []
    traces: list[list[dict[str, Any]]] = []
    graph_runtimes: list[float] = []
    attempts_per_graph: list[int] = []
    attempts_per_slot: list[int] = []
    skipped_graphs: list[dict[str, Any]] = []
    generated_indices: list[int] = []
    constructor_records: list[dict[str, Any]] = []
    source_metadata: list[dict[str, Any]] = []
    audits: list[dict[str, bool]] = []
    rejection_reasons: Counter[str] = Counter()

    def save_partial(error: Exception | None = None, stage: str | None = None) -> None:
        _atomic_pickle(final_graphs, output_dir / "molecular_graphs.partial.pkl")
        _atomic_pickle(source_graphs, output_dir / "typed_source_graphs.partial.pkl")
        if source_enrichment_enabled:
            _atomic_pickle(enriched_base_graphs, output_dir / "enriched_base_graphs.partial.pkl")
        partial = _partial_report(
            generated=len(final_graphs), requested=num_generate,
            attempts=attempts_per_slot, started=started, skipped_graphs=skipped_graphs,
            rejection_reasons=rejection_reasons, generated_indices=generated_indices,
            max_total_graph_attempts=max_total_graph_attempts,
        )
        if error is not None:
            partial.update(failure=str(error), failed_generation_index=len(attempts_per_slot) - 1,
                           failure_stage=stage)
        _atomic_json(partial, output_dir / "partial_report.json")

    for graph_index in range(max_total_graph_attempts):
        if len(final_graphs) >= num_generate:
            break
        graph_started = time.perf_counter()
        succeeded = False
        attempts_per_slot.append(0)
        slot_rejections: Counter[str] = Counter()
        last_failure: dict[str, Any] = {}
        for attempt in range(1, max_attempts + 1):
            attempts_per_slot[-1] = attempt
            stage = "invariant_sampling"
            try:
                invariant, invariant_metadata = _sample_invariant(
                    invariant_source,
                    index=graph_index,
                    train_graphs=train_graphs,
                    test_graphs=test_graphs,
                    typed_sampler=typed_sampler,
                    rng=source_rng,
                    edge_types=tuple(vocabulary.edge_values),
                    node_attribute=node_attribute,
                    edge_attribute=edge_attribute,
                )
                if tuple(invariant.edge_types) != tuple(vocabulary.edge_values):
                    raise ValueError(
                        "Typed invariant edge vocabulary does not match predictor checkpoint."
                    )
                if invariant.node_attribute != node_attribute or invariant.edge_attribute != edge_attribute:
                    raise ValueError(
                        "Typed invariant attribute names do not match predictor checkpoint."
                    )

                stage = "source_construction"
                source, constructor_record = construct_typed_graph(
                    invariant,
                    constructor_cfg,
                    source_rng,
                )
                source = _complete_molecular_aliases(
                    source,
                    node_attribute=node_attribute,
                    edge_attribute=edge_attribute,
                )
                indexed_source_typed_invariant = extract_typed_invariant(
                    source,
                    edge_types=vocabulary.edge_values,
                    node_attribute=node_attribute,
                    edge_attribute=edge_attribute,
                )
                indexed_source_rewiring_invariant = extract_attributed_rewiring_invariant(
                    source,
                    edge_types=vocabulary.edge_values,
                    node_attribute=node_attribute,
                    edge_attribute=edge_attribute,
                )
                stage = "source_validation"
                source_is_valid = _generation_rdkit_valid(
                    source,
                    infer_projected_formal_charges=(
                        refiner_cfg.rdkit_infer_projected_formal_charges
                    ),
                )
                source_is_raw_valid = is_valid_molecular_graph(source)
                if require_source_validity and not source_is_valid:
                    rejection_reasons["rdkit_invalid_source"] += 1
                    slot_rejections["rdkit_invalid_source"] += 1
                    last_failure = {"stage": stage, "reason": "rdkit_invalid_source"}
                    continue

                base_graph = source
                enrichment_trace: list[dict[str, Any]] = []
                if source_enrichment_enabled:
                    stage = "source_enrichment"
                    assert source_enrichment_refiner is not None
                    enrichment_rng = np.random.default_rng(
                        np.random.SeedSequence([seed, graph_index, attempt, 3571])
                    )
                    base_graph, enrichment_trace = enrich_attributed_graph_with_invariant_summary(
                        model,
                        source,
                        vocabulary=vocabulary,
                        graphlet_basis=graphlet_basis,
                        config=source_enrichment_refiner,
                        device=model_device,
                        rng=enrichment_rng,
                        return_trace=True,
                        debug_context=(f"graph={len(final_graphs) + 1}/{num_generate} "
                                       f"trial={graph_index + 1}/{max_total_graph_attempts}"),
                    )
                    base_graph = _complete_molecular_aliases(
                        base_graph,
                        node_attribute=node_attribute,
                        edge_attribute=edge_attribute,
                    )
                    if not attributed_rewiring_invariant_matches_graph(
                        base_graph, indexed_source_rewiring_invariant
                    ):
                        raise AssertionError("Source enrichment changed the hard molecular invariant.")
                    if base_graph.number_of_nodes() > 1 and not nx.is_connected(base_graph):
                        raise AssertionError("Source enrichment returned a disconnected molecule.")

                stage = "refinement"
                attempt_rng = np.random.default_rng(
                    np.random.SeedSequence([seed, graph_index, attempt, 7919])
                )
                refined, trace = refine_attributed_graph_with_spectral_graphlet_diffusion(
                    model,
                    base_graph,
                    vocabulary=vocabulary,
                    graphlet_basis=graphlet_basis,
                    config=refiner_cfg,
                    device=model_device,
                    rng=attempt_rng,
                    return_trace=True,
                    debug_context=(f"graph={len(final_graphs) + 1}/{num_generate} "
                                   f"trial={graph_index + 1}/{max_total_graph_attempts}"),
                    conditioning_graph=source,
                )
                refined = _complete_molecular_aliases(
                    refined,
                    node_attribute=node_attribute,
                    edge_attribute=edge_attribute,
                )
                if not attributed_rewiring_invariant_matches_graph(
                    refined, indexed_source_rewiring_invariant
                ):
                    raise AssertionError(
                        "Refinement changed node types, indexed ordinary degrees, or "
                        "global bond-type counts."
                    )
                if (
                    refiner_cfg.preserve_typed_degree
                    and not typed_invariant_matches_graph(
                        refined, indexed_source_typed_invariant
                    )
                ):
                    raise AssertionError(
                        "Strict refinement changed the indexed typed-degree invariant."
                    )
                if refined.number_of_nodes() > 1 and not nx.is_connected(refined):
                    raise AssertionError("Refinement returned a disconnected molecule.")
                stage = "final_validation"
                final_is_valid = _generation_rdkit_valid(
                    refined,
                    infer_projected_formal_charges=(
                        refiner_cfg.rdkit_infer_projected_formal_charges
                    ),
                )
                final_is_raw_valid = is_valid_molecular_graph(refined)
                if require_final_validity and not final_is_valid:
                    rejection_reasons["rdkit_invalid_final"] += 1
                    slot_rejections["rdkit_invalid_final"] += 1
                    last_failure = {"stage": stage, "reason": "rdkit_invalid_final"}
                    continue

                stage = "output_audit"
                audit = _preservation_audit(
                    source, refined, node_attribute=node_attribute, edge_attribute=edge_attribute,
                )
                source_graphs.append(source)
                enriched_base_graphs.append(base_graph)
                final_graphs.append(refined)
                enrichment_traces.append(enrichment_trace)
                traces.append(trace)
                graph_runtimes.append(float(time.perf_counter() - graph_started))
                attempts_per_graph.append(attempt)
                generated_indices.append(graph_index)
                constructor_records.append(
                    {
                        **constructor_record,
                        "generation_index": graph_index,
                        "generation_attempt": attempt,
                        "rdkit_validation_mode": refiner_cfg.rdkit_validation_mode,
                        "source_rdkit_valid": source_is_raw_valid,
                        "final_rdkit_valid": final_is_raw_valid,
                        "source_rdkit_valid_configured": source_is_valid,
                        "final_rdkit_valid_configured": final_is_valid,
                    }
                )
                source_metadata.append({**invariant_metadata, "generation_index": graph_index})
                audits.append(audit)
                enrichment_accepted = sum(
                    bool(row.get("accepted")) for row in enrichment_trace
                )
                accepted = sum(bool(row.get("accepted")) for row in trace)
                prediction_calls = max(
                    (int(row.get("prediction_calls", 0)) for row in trace), default=0
                )
                print(
                    f"graph={len(final_graphs)}/{num_generate} "
                    f"trial={graph_index + 1}/{max_total_graph_attempts} guidance=attributed_spectral_graphlet "
                    f"n={refined.number_of_nodes()} m={refined.number_of_edges()} "
                    f"enrichment_steps={enrichment_accepted} accepted_steps={accepted} "
                    f"prediction_calls={prediction_calls} "
                    f"source_valid={source_is_valid} final_valid={final_is_valid} "
                    f"attempts={attempt} runtime={graph_runtimes[-1]:.3f}s",
                    flush=True,
                )
                succeeded = True
                break
            except TypedConstructionError as exc:
                if stage != "source_construction":
                    save_partial(exc, stage)
                    raise
                reason = str(exc.diagnostics.get("failure_reason", "failed"))
                rejection_reasons[f"constructor:{reason}"] += 1
                slot_rejections[f"constructor:{reason}"] += 1
                last_failure = {"stage": stage, "reason": reason, "error": str(exc),
                                "constructor_diagnostics": dict(exc.diagnostics)}
            except RuntimeError as exc:
                # The legacy typed VAE uses RuntimeError for this one expected
                # feasibility-budget failure. Other runtime failures remain fatal.
                if (stage != "invariant_sampling"
                        or invariant_source not in {"learned", "typed_vae", "degree_vae"}
                        or not str(exc).startswith(
                    "Typed invariant sampling exhausted its feasibility budget:"
                )):
                    save_partial(exc, stage)
                    raise
                rejection_reasons["typed_prior_feasibility_budget"] += 1
                slot_rejections["typed_prior_feasibility_budget"] += 1
                last_failure = {"stage": stage, "reason": "typed_prior_feasibility_budget",
                                "error": str(exc)}
            except Exception as exc:
                save_partial(exc, stage)
                raise

        if not succeeded:
            skipped_graphs.append({
                "generation_index": graph_index, "attempts_used": attempt,
                **last_failure, "generation_rejections": dict(sorted(slot_rejections.items())),
                "runtime_seconds": float(time.perf_counter() - graph_started),
            })
            print(
                f"[GraphER/AttributedSpectralGraphlet] graph={len(final_graphs) + 1}/{num_generate} "
                f"trial={graph_index + 1}/{max_total_graph_attempts} "
                f"skipped=True attempts={attempt} stage={last_failure.get('stage')} "
                f"reason={last_failure.get('reason')} rejections={dict(slot_rejections)} "
                f"action={'resample_replacement' if graph_index + 1 < max_total_graph_attempts else 'stop_total_budget_exhausted'}",
                flush=True,
            )

        if checkpoint_every > 0 and (graph_index + 1) % checkpoint_every == 0:
            save_partial()
            print(
                f"Saved atomic partial generation checkpoint: attempted={graph_index + 1}/{max_total_graph_attempts} "
                f"generated={len(final_graphs)}/{num_generate} skipped={len(skipped_graphs)}",
                flush=True,
            )

    trace_rows = [row for trace in traces for row in trace]
    enrichment_trace_rows = [row for trace in enrichment_traces for row in trace]
    accepted_rows = [row for row in trace_rows if bool(row.get("accepted"))]
    enrichment_accepted_rows = [
        row for row in enrichment_trace_rows if bool(row.get("accepted"))
    ]
    source_validity = [is_valid_molecular_graph(graph) for graph in source_graphs]
    final_validity = [is_valid_molecular_graph(graph) for graph in final_graphs]
    configured_source_validity = [
        is_valid_molecular_graph(
            graph,
            infer_projected_formal_charges=(
                refiner_cfg.rdkit_infer_projected_formal_charges
            ),
        )
        for graph in source_graphs
    ]
    configured_final_validity = [
        is_valid_molecular_graph(
            graph,
            infer_projected_formal_charges=(
                refiner_cfg.rdkit_infer_projected_formal_charges
            ),
        )
        for graph in final_graphs
    ]
    rewiring_invariant_preservation = [
        attributed_rewiring_invariant_matches_graph(
            final,
            extract_attributed_rewiring_invariant(
                source,
                edge_types=vocabulary.edge_values,
                node_attribute=node_attribute,
                edge_attribute=edge_attribute,
            ),
        )
        for source, final in zip(source_graphs, final_graphs)
    ]
    # Typed-degree preservation is now a diagnostic rather than a required
    # invariant.  Cross-type bond reassignment is expected to change it.
    typed_preservation = [
        typed_invariant_matches_graph(
            final,
            extract_typed_invariant(
                source,
                edge_types=vocabulary.edge_values,
                node_attribute=node_attribute,
                edge_attribute=edge_attribute,
            ),
        )
        for source, final in zip(source_graphs, final_graphs)
    ]
    accepted_counts = [
        sum(bool(row.get("accepted")) for row in trace) for trace in traces
    ]
    prediction_counts = [
        max((int(row.get("prediction_calls", 0)) for row in trace), default=0)
        for trace in traces
    ]
    generation_summary = {
        "complete": True,
        "num_requested": num_generate,
        "num_attempted": len(attempts_per_slot),
        "num_generated": len(final_graphs),
        "num_skipped": len(skipped_graphs),
        "skipped_graphs": skipped_graphs,
        "generated_indices": generated_indices,
        "requested_count_reached": len(final_graphs) == num_generate,
        "max_total_graph_attempts": max_total_graph_attempts,
        "replacement_attempts": max(0, len(attempts_per_slot) - num_generate),
        "replacement_budget_exhausted": (len(final_graphs) < num_generate
                                         and len(attempts_per_slot) >= max_total_graph_attempts),
        "generation_success_fraction": float(len(final_graphs) / max(len(attempts_per_slot), 1)),
        "generation_attempts": int(sum(attempts_per_slot)),
        "end_to_end_yield": float(len(final_graphs) / max(sum(attempts_per_slot), 1)),
        "generation_rejections": dict(sorted(rejection_reasons.items())),
    }
    diagnostics = {
        **generation_summary,
        "pipeline_mode": "attributed",
        "guidance_mode": "dual_spectral_attributed_graphlet",
        "invariant_source": invariant_source,
        "source_enrichment_enabled": bool(source_enrichment_enabled),
        "rdkit_validation_mode": refiner_cfg.rdkit_validation_mode,
        "graphlet_logit_distance_weight": float(
            refiner_cfg.graphlet_logit_distance_weight
        ),
        "graphlet_probability_distance_weight": float(
            refiner_cfg.graphlet_probability_distance_weight
        ),
        "graphlet_selected_mass_weight": float(
            refiner_cfg.graphlet_selected_mass_weight
        ),
        "typed_degree_drift_weight": float(
            refiner_cfg.typed_degree_drift_weight
        ),
        "weighted_valence_drift_weight": float(
            refiner_cfg.weighted_valence_drift_weight
        ),
        "num_generated": len(final_graphs),
        "mean_source_enrichment_accepted_steps": float(
            np.mean([sum(bool(row.get("accepted")) for row in trace) for trace in enrichment_traces])
        ) if enrichment_traces else 0.0,
        "mean_source_enrichment_candidate_pass_rate": _mean(
            enrichment_trace_rows, "candidate_pass_rate"
        ),
        "mean_source_enrichment_energy_improvement": _mean(
            enrichment_accepted_rows, "energy_improvement"
        ),
        "rewiring_invariant_preservation_rate": _mean_values(rewiring_invariant_preservation),
        "typed_degree_preservation_rate": _mean_values(typed_preservation),
        "mean_typed_degree_changed_node_fraction": _mean(audits, "typed_degree_changed_node_fraction"),
        # Compatibility alias retained for older report readers.  In revised
        # cross-type mode this is diagnostic and is not expected to be 1.0.
        "typed_invariant_preservation_rate": _mean_values(typed_preservation),
        "node_type_preservation_rate": _mean(audits, "node_type_preserved"),
        "indexed_degree_preservation_rate": _mean(audits, "indexed_degree_preserved"),
        "edge_type_count_preservation_rate": _mean(audits, "edge_type_counts_preserved"),
        "per_node_weighted_valence_preservation_rate": _mean(audits, "weighted_valence_preserved"),
        # Compatibility alias; per-node weighted valence is no longer a hard
        # invariant under cross-type reassignment.
        "weighted_valence_preservation_rate": _mean(audits, "weighted_valence_preserved"),
        "connectedness_rate": _mean_values([
            graph.number_of_nodes() <= 1 or nx.is_connected(graph) for graph in final_graphs
        ]),
        # Raw/no-correction rates match evaluate_generated_molecules.py.
        "rdkit_valid_source_rate": _mean_values(source_validity),
        "rdkit_valid_final_rate": _mean_values(final_validity),
        "rdkit_valid_source_rate_raw": _mean_values(source_validity),
        "rdkit_valid_final_rate_raw": _mean_values(final_validity),
        "rdkit_valid_source_rate_configured": _mean_values(configured_source_validity),
        "rdkit_valid_final_rate_configured": _mean_values(configured_final_validity),
        "mean_accepted_steps": _mean_values(accepted_counts),
        "mean_prediction_calls": _mean_values(prediction_counts),
        "mean_accepted_swaps_per_prediction_call": float(
            sum(accepted_counts) / max(sum(prediction_counts), 1)
        ),
        "mean_accepted_spectral_gain": _mean(accepted_rows, "spectral_gain"),
        "mean_accepted_topology_spectral_gain": _mean(
            accepted_rows, "topology_spectral_gain"
        ),
        "mean_accepted_bond_spectral_gain": _mean(
            accepted_rows, "bond_spectral_gain"
        ),
        "mean_accepted_graphlet_gain": _mean(accepted_rows, "graphlet_gain"),
        "mean_accepted_graphlet_logit_gain": _mean(
            accepted_rows, "graphlet_logit_gain"
        ),
        "mean_accepted_graphlet_probability_gain": _mean(
            accepted_rows, "graphlet_probability_gain"
        ),
        "mean_accepted_graphlet_selected_mass_gain": _mean(
            accepted_rows, "graphlet_selected_mass_gain"
        ),
        "mean_accepted_chemistry_drift_gain": _mean(
            accepted_rows, "chemistry_drift_gain"
        ),
        "mean_accepted_typed_degree_drift_gain": _mean(
            accepted_rows, "typed_degree_drift_gain"
        ),
        "mean_accepted_weighted_valence_drift_gain": _mean(
            accepted_rows, "weighted_valence_drift_gain"
        ),
        "mean_projection_residual": _mean(accepted_rows, "projection_residual"),
        "mean_spectral_projection_residual": _mean(
            accepted_rows, "spectral_projection_residual"
        ),
        "mean_topology_spectral_projection_residual": _mean(
            accepted_rows, "topology_spectral_projection_residual"
        ),
        "mean_bond_spectral_projection_residual": _mean(
            accepted_rows, "bond_spectral_projection_residual"
        ),
        "mean_graphlet_projection_residual": _mean(
            accepted_rows, "graphlet_projection_residual"
        ),
        "mean_graphlet_logit_projection_residual": _mean(
            accepted_rows, "graphlet_logit_projection_residual"
        ),
        "mean_graphlet_probability_projection_residual": _mean(
            accepted_rows, "graphlet_probability_projection_residual"
        ),
        "mean_graphlet_selected_mass_projection_residual": _mean(
            accepted_rows, "graphlet_selected_mass_projection_residual"
        ),
        "mean_chemistry_drift_penalty": _mean(
            accepted_rows, "chemistry_drift_penalty"
        ),
        "mean_typed_degree_drift": _mean(accepted_rows, "typed_degree_drift"),
        "mean_weighted_valence_drift": _mean(
            accepted_rows, "weighted_valence_drift"
        ),
        "predictor_topology_spectral_nrmse": predictor_report.get(
            "val_topology_spectral_nrmse",
            predictor_report.get("topology_spectral_nrmse"),
        ),
        "predictor_bond_spectral_nrmse": predictor_report.get(
            "val_bond_spectral_nrmse",
            predictor_report.get("bond_spectral_nrmse"),
        ),
        "predictor_graphlet_logit_rmse": predictor_report.get(
            "val_graphlet_logit_rmse",
            predictor_report.get("graphlet_logit_rmse"),
        ),
        "predictor_graphlet_probability_mae": predictor_report.get(
            "val_graphlet_probability_mae",
            predictor_report.get("graphlet_probability_mae"),
        ),
        "predictor_graphlet_selected_mass_mae": predictor_report.get(
            "val_graphlet_selected_mass_mae",
            predictor_report.get("graphlet_selected_mass_mae"),
        ),
        "mean_candidate_pass_rate": _mean(trace_rows, "candidate_pass_rate"),
        "rdkit_candidates_checked": int(
            sum(int(row.get("rdkit_checked", 0)) for row in trace_rows)
        ),
        "rdkit_candidates_rejected": int(
            sum(int(row.get("rdkit_rejected", 0)) for row in trace_rows)
        ),
        "mean_graph_runtime_seconds": _mean_values(graph_runtimes),
        "mean_attempts_per_generated_graph": _mean_values(attempts_per_graph),
        "runtime_seconds": float(time.perf_counter() - started),
        "rejection_reasons": dict(sorted(rejection_reasons.items())),
    }

    save_pickle(source_graphs, output_dir / "typed_source_graphs.pkl")
    if source_enrichment_enabled:
        save_pickle(enriched_base_graphs, output_dir / "enriched_base_graphs.pkl")
    save_pickle(final_graphs, output_dir / "molecular_graphs.pkl")
    save_pickle(final_graphs, output_dir / "generated_graphs.pkl")
    valid_smiles = [
        smiles
        for graph in final_graphs
        for smiles in [graph_to_smiles(graph, canonical=True, sanitize=True)]
        if smiles is not None
    ]
    (output_dir / "generated.smi").write_text(
        "\n".join(valid_smiles) + ("\n" if valid_smiles else ""),
        encoding="utf-8",
    )
    report = {
        **generation_summary,
        "format": "attributed_spectral_graphlet_generation_v2",
        "checkpoint_format": checkpoint.get("format"),
        "training_state_source": checkpoint.get("config", {})
        .get("summary_diffusion", {})
        .get("bridge", "continuous_summary_diffusion"),
        "rewiring_used_during_training": False,
        "rewiring_used_during_generation": True,
        "rewiring_kernel": (
            "same_edge_type"
            if refiner_cfg.require_same_edge_type_pair
            else "bond_reassigning_cross_type"
        ),
        "hard_rewiring_invariant": [
            "indexed_node_types",
            "indexed_ordinary_degrees",
            "global_edge_type_counts",
        ],
        "spectral_channels": ["topology", "bond_weighted"],
        "graphlet_orders": list(graphlet_basis.sizes),
        "graphlet_topology_filter": graphlet_basis.topology_filter,
        "vocabulary": vocabulary.to_dict(),
        "summary_config": dict(summary_config.__dict__),
        "diagnostics": diagnostics,
        "constructor_records": constructor_records,
        "source_metadata": source_metadata,
        "source_enrichment_traces": enrichment_traces if store_traces else [],
        "traces": traces if store_traces else [],
        "seed": seed,
        "config": config,
    }
    save_json(report, output_dir / "report.json")
    if generation_summary["replacement_budget_exhausted"]:
        print(
            f"[GraphER/AttributedSpectralGraphlet] total graph-attempt budget exhausted "
            f"({max_total_graph_attempts}); saved {len(final_graphs)}/{num_generate} requested graphs "
            f"to {output_dir}.",
            flush=True,
        )
    print("Attributed generation diagnostics", flush=True)
    for key, value in diagnostics.items():
        print(f"  {key}: {value}", flush=True)
    print(f"Saved results to: {output_dir}", flush=True)


if __name__ == "__main__":
    main()
