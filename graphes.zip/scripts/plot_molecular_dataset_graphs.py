#!/usr/bin/env python
from __future__ import annotations

import argparse
import math
from collections import Counter
from pathlib import Path

import matplotlib.pyplot as plt
import networkx as nx
import numpy as np

from grapher.data.io import load_dataset_splits
from grapher.molecular.constants import (
    BOND_AROMATIC,
    BOND_DOUBLE,
    BOND_SINGLE,
    BOND_TRIPLE,
    QM9_ATOM_SYMBOLS,
)
from grapher.utils.io import ensure_dir
from grapher.utils.motifs import aggregate_unique_motifs_with_counts


ATOM_COLORS = {
    6: "#4c78a8",  # C
    7: "#54a24b",  # N
    8: "#e45756",  # O
    9: "#f2cf5b",  # F
}

BOND_COLORS = {
    BOND_SINGLE: "#7f7f7f",
    BOND_DOUBLE: "#f58518",
    BOND_TRIPLE: "#b279a2",
    BOND_AROMATIC: "#72b7b2",
}

def _node_label(graph: nx.Graph, node: int) -> str:
    data = graph.nodes[node]
    atomic_num = int(data.get("atomic_num", data.get("atom_type", 0)))
    return QM9_ATOM_SYMBOLS.get(atomic_num, str(atomic_num))


def _node_color(graph: nx.Graph, node: int) -> str:
    data = graph.nodes[node]
    atomic_num = int(data.get("atomic_num", data.get("atom_type", 0)))
    return ATOM_COLORS.get(atomic_num, "#bab0ac")


def _edge_color(graph: nx.Graph, u: int, v: int) -> str:
    data = graph.edges[u, v]
    bond_type = int(data.get("bond_type", data.get("bond_order", 1)))
    return BOND_COLORS.get(bond_type, "#7f7f7f")


def _edge_width(graph: nx.Graph, u: int, v: int) -> float:
    data = graph.edges[u, v]
    bond_type = int(data.get("bond_type", data.get("bond_order", 1)))

    if bond_type == BOND_DOUBLE:
        return 2.2
    if bond_type == BOND_TRIPLE:
        return 2.8
    return 1.6


def _graph_statistics(graphs: list[nx.Graph]) -> dict[str, object]:
    node_counts = np.asarray([g.number_of_nodes() for g in graphs], dtype=float)
    edge_counts = np.asarray([g.number_of_edges() for g in graphs], dtype=float)

    atom_counts: Counter[str] = Counter()
    bond_counts: Counter[str] = Counter()

    for graph in graphs:
        for node in graph.nodes():
            atom_counts[_node_label(graph, int(node))] += 1

        for u, v in graph.edges():
            data = graph.edges[u, v]
            bond_type = int(data.get("bond_type", data.get("bond_order", 1)))

            if bond_type == BOND_SINGLE:
                name = "single"
            elif bond_type == BOND_DOUBLE:
                name = "double"
            elif bond_type == BOND_TRIPLE:
                name = "triple"
            elif bond_type == BOND_AROMATIC:
                name = "aromatic"
            else:
                name = str(bond_type)

            bond_counts[name] += 1

    def summarize(values: np.ndarray) -> dict[str, float]:
        if values.size == 0:
            return {"min": 0.0, "mean": 0.0, "max": 0.0}

        return {
            "min": float(values.min()),
            "mean": float(values.mean()),
            "max": float(values.max()),
        }

    return {
        "num_graphs": len(graphs),
        "nodes": summarize(node_counts),
        "edges": summarize(edge_counts),
        "atom_counts": dict(sorted(atom_counts.items())),
        "bond_counts": dict(sorted(bond_counts.items())),
    }


def _print_statistics(name: str, graphs: list[nx.Graph]) -> None:
    stats = _graph_statistics(graphs)

    print(f"{name}:")
    print(f"  graphs: {stats['num_graphs']}")

    print(
        "  nodes: "
        f"min={stats['nodes']['min']:.0f} "
        f"mean={stats['nodes']['mean']:.2f} "
        f"max={stats['nodes']['max']:.0f}"
    )

    print(
        "  edges: "
        f"min={stats['edges']['min']:.0f} "
        f"mean={stats['edges']['mean']:.2f} "
        f"max={stats['edges']['max']:.0f}"
    )

    print(f"  atoms: {stats['atom_counts']}")
    print(f"  bonds: {stats['bond_counts']}")


def _draw_graph(
    ax,
    graph: nx.Graph,
    title: str,
    *,
    use_color: bool = True,
    show_node_labels: bool = True,
) -> None:
    graph = nx.convert_node_labels_to_integers(nx.Graph(graph), ordering="sorted")
    pos = nx.spring_layout(graph, seed=0)

    labels = {node: _node_label(graph, node) for node in graph.nodes()}
    edge_widths = [_edge_width(graph, u, v) for u, v in graph.edges()]

    if use_color:
        node_colors = [_node_color(graph, node) for node in graph.nodes()]
        edge_colors = [_edge_color(graph, u, v) for u, v in graph.edges()]
        font_color = "#ffffff"
    else:
        node_colors = "#f2f2f2"
        edge_colors = "#555555"
        font_color = "black"

    nx.draw_networkx_edges(
        graph,
        pos,
        ax=ax,
        width=edge_widths,
        edge_color=edge_colors,
    )

    nx.draw_networkx_nodes(
        graph,
        pos,
        ax=ax,
        node_size=520,
        node_color=node_colors,
        edgecolors="#222222",
        linewidths=1.2,
    )

    if show_node_labels:
        nx.draw_networkx_labels(
            graph,
            pos,
            labels=labels,
            ax=ax,
            font_size=9,
            font_color=font_color,
        )

    ax.set_title(title, fontsize=9)
    ax.set_axis_off()


def simplify_graph(graph: nx.Graph) -> nx.Graph:
    """
    Simplify a molecular graph by removing unnecessary attributes and
    keeping only atom type and bond type.
    """
    simple_graph = nx.Graph()

    for node, data in graph.nodes(data=True):
        atomic_num = int(data.get("atomic_num", data.get("atom_type", 0)))
        simple_graph.add_node(node, atomic_num=atomic_num)

    for u, v, data in graph.edges(data=True):
        bond_type = int(data.get("bond_type", data.get("bond_order", 1)))
        simple_graph.add_edge(u, v, bond_type=bond_type)

    return simple_graph


def _plot_grid(
    graphs: list[nx.Graph],
    indices: list[int],
    *,
    split: str,
    cols: int,
    output_path: Path,
    use_color: bool,
    show_node_labels: bool,
    titles: list[str] | None = None,
) -> None:
    rows = int(math.ceil(len(graphs) / cols))
    fig, axes = plt.subplots(
        rows,
        cols,
        figsize=(3.2 * cols, 3.0 * rows),
        squeeze=False,
    )

    for ax in axes.reshape(-1):
        ax.set_axis_off()

    for pos_idx, (ax, graph, idx) in enumerate(zip(axes.reshape(-1), graphs, indices)):
        title = (
            titles[pos_idx]
            if titles is not None
            else f"{split}[{idx}] n={graph.number_of_nodes()} m={graph.number_of_edges()}"
        )
        _draw_graph(
            ax,
            graph,
            title,
            use_color=use_color,
            show_node_labels=show_node_labels,
        )

    fig.tight_layout()
    fig.savefig(output_path, dpi=200)
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Plot a sample of graphs from a molecular dataset split."
    )

    parser.add_argument("--dataset", default="qm9_attributed")
    parser.add_argument("--root", default="outputs/datasets")
    parser.add_argument("--split", default="train", choices=["train", "val", "test"])
    parser.add_argument("--num-graphs", type=int, default=16)
    parser.add_argument(
        "--seed",
        type=int,
        default=0,
        help="Seed used when --sample-random is set.",
    )
    parser.add_argument(
        "--sample-random",
        action="store_true",
        help="Sample random graphs instead of taking the first N.",
    )
    parser.add_argument("--output-dir", default="outputs/plots/molecular_dataset")
    parser.add_argument(
        "--filename",
        default=None,
        help="Defaults to <dataset>_<split>_<num>.png.",
    )
    parser.add_argument("--cols", type=int, default=4)
    parser.add_argument("--motif-min-size", type=int, default=3, help="Minimum motif node count k.")
    parser.add_argument("--motif-max-size", type=int, default=6, help="Maximum motif node count k.")
    parser.add_argument("--max-motifs", type=int, default=0, help="Maximum number of unique motifs to plot per k; 0 plots all.")
    parser.add_argument(
        "--stats-all-splits",
        action="store_true",
        help="Print statistics for train/val/test, not only the requested split.",
    )

    args = parser.parse_args()

    splits = load_dataset_splits(
        args.dataset,
        root=args.root,
        build_if_missing=False,
    )

    graphs = list(splits[args.split])

    if not graphs:
        raise RuntimeError(f"No graphs found for {args.dataset}/{args.split}.")

    print(f"Dataset: {args.dataset}")
    print(f"Root: {args.root}")
    print(f"Split sizes: { {split: len(items) for split, items in splits.items()} }")

    if args.stats_all_splits:
        for split, split_graphs in splits.items():
            _print_statistics(f"Split {split}", list(split_graphs))
    else:
        _print_statistics(f"Split {args.split}", graphs)

    n = min(int(args.num_graphs), len(graphs))

    if n <= 0:
        raise ValueError("--num-graphs must be positive.")

    if args.sample_random:
        rng = np.random.default_rng(int(args.seed))
        indices = rng.choice(len(graphs), size=n, replace=False).tolist()
    else:
        indices = list(range(n))

    selected = [graphs[i] for i in indices]

    _print_statistics("Selected graphs", selected)

    simplified = [simplify_graph(graph) for graph in selected]

    _print_statistics("Selected simplified graphs", simplified)

    all_simplified = [simplify_graph(graph) for graph in graphs]
    _print_statistics(f"All simplified graphs in split {args.split}", all_simplified)

    motif_min_size = int(args.motif_min_size)
    motif_max_size = int(args.motif_max_size)
    if motif_min_size <= 0:
        raise ValueError("--motif-min-size must be positive.")
    if motif_max_size < motif_min_size:
        raise ValueError("--motif-max-size must be greater than or equal to --motif-min-size.")

    motifs_by_size: dict[int, list[tuple[nx.Graph, int]]] = {}
    for k in range(motif_min_size, motif_max_size + 1):
        motifs = aggregate_unique_motifs_with_counts(all_simplified, k)
        if args.max_motifs is not None and int(args.max_motifs) > 0:
            motifs = motifs[: int(args.max_motifs)]
        motifs_by_size[k] = motifs

        if motifs:
            motif_graphs = [motif for motif, _count in motifs]
            motif_counts = [count for _motif, count in motifs]
            _print_statistics(f"Unique {k}-node motifs", motif_graphs)
            print(f"  occurrences: {motif_counts}")
        else:
            print(f"Unique {k}-node motifs: 0")

    cols = max(1, int(args.cols))
    out_dir = ensure_dir(args.output_dir)

    filename = args.filename or f"{args.dataset}_{args.split}_{n}.png"
    out_path = Path(out_dir) / filename

    simple_filename = f"{out_path.stem}_simple{out_path.suffix}"
    simple_out_path = out_path.with_name(simple_filename)
    motif_paths: list[Path] = []

    # Original molecular graph plot: colored atoms and bonds.
    _plot_grid(
        selected,
        indices,
        split=args.split,
        cols=cols,
        output_path=out_path,
        use_color=True,
        show_node_labels=True,
    )

    # Simplified molecular graph plot: grayscale topology only.
    _plot_grid(
        simplified,
        indices,
        split=args.split,
        cols=cols,
        output_path=simple_out_path,
        use_color=False,
        show_node_labels=False,
    )
    for k, motifs in motifs_by_size.items():
        if not motifs:
            continue

        motif_graphs = [motif for motif, _count in motifs]
        motif_titles = [
            f"motif[{idx}] count={count}"
            for idx, (_motif, count) in enumerate(motifs)
        ]
        motif_out_path = out_path.with_name(f"{out_path.stem}_motifs_k{k}{out_path.suffix}")
        _plot_grid(
            motif_graphs,
            list(range(len(motif_graphs))),
            split="motif",
            cols=cols,
            output_path=motif_out_path,
            use_color=False,
            show_node_labels=False,
            titles=motif_titles,
        )
        motif_paths.append(motif_out_path)

    print(f"Saved plot to: {out_path}")
    print(f"Saved simplified plot to: {simple_out_path}")
    for motif_path in motif_paths:
        print(f"Saved motif plot to: {motif_path}")


if __name__ == "__main__":
    main()
