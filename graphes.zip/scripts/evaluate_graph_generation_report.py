#!/usr/bin/env python
"""Create the paper-facing MMD table and generated-graph sample figure."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import re
from collections import Counter
from pathlib import Path
from typing import Any, Sequence

os.environ.setdefault("MPLBACKEND", "Agg")
os.environ.setdefault("MPLCONFIGDIR", "/tmp/grapher-matplotlib")

import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
from matplotlib.lines import Line2D

from grapher.data.io import load_dataset_splits
from grapher.rewiring_mlp.evaluation.metrics import (
    descriptor_matrix,
    mmd_gaussian_emd,
    mmd_orbit,
    mmd_orbit_graphrnn,
)
from grapher.rewiring_mlp.molecular.graph_io import nx_to_rdkit_mol, require_rdkit
from grapher.properties.summary import (
    clustering_histogram,
    configure_orca_executable,
    degree_histogram,
)
from grapher.utils.io import ensure_dir, load_pickle, load_yaml, save_json

REPORT_METRICS = ("degree_mmd", "clustering_mmd", "orbit_mmd")
ATOM_COLORS = {
    1: "#F3F4F6",
    6: "#374151",
    7: "#2563EB",
    8: "#DC2626",
    9: "#16A34A",
}
ATOM_LABELS = {1: "H", 6: "C", 7: "N", 8: "O", 9: "F"}


def _load_graph_list(path: Path) -> list[nx.Graph]:
    value = load_pickle(path)
    if isinstance(value, dict):
        for key in (
            "graphs",
            "generated_graphs",
            "topology_refined_graphs",
            "hybrid_refined_graphs",
        ):
            if key in value:
                value = value[key]
                break
    if not isinstance(value, (list, tuple)):
        raise TypeError(f"{path} does not contain a graph list.")
    graphs = list(value)
    if not all(isinstance(graph, nx.Graph) for graph in graphs):
        raise TypeError(f"{path} contains a non-NetworkX graph.")
    if not graphs:
        raise ValueError(f"{path} contains no graphs.")
    return graphs


def _load_json_mapping(path: Path) -> dict[str, Any] | None:
    """Load an optional JSON object while rejecting malformed provenance."""

    if not path.is_file():
        return None
    try:
        with path.open("r", encoding="utf-8") as handle:
            value = json.load(handle)
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f"Could not read JSON manifest {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise TypeError(f"JSON manifest {path} must contain an object.")
    return value



def _sha256(path: Path) -> str:
    """Return the SHA-256 digest of one on-disk artifact."""

    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _combined_split_fingerprint(split_sha256: dict[str, str]) -> str:
    """Match the baseline-wrapper dataset fingerprint convention."""

    record = {
        split: {"path": f"{split}.pkl", "sha256": split_sha256[split]}
        for split in sorted(split_sha256)
    }
    payload = json.dumps(record, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def dataset_provenance(
    dataset_config: dict[str, Any],
    splits: dict[str, Sequence[nx.Graph]],
) -> dict[str, Any]:
    """Describe the exact prepared dataset used by this evaluation.

    Evaluation must be reproducible across machines.  The split pickle hashes
    are therefore treated as the primary dataset identity, while the protocol
    ID and config hashes provide human-readable provenance.
    """

    serialized_id = str(dataset_config.get("name", "sbm"))
    benchmark_id = str(dataset_config.get("benchmark", serialized_id))
    root = Path(dataset_config.get("root", "outputs/datasets"))
    directory = root / serialized_id
    split_paths = {
        split: directory / f"{split}.pkl" for split in ("train", "val", "test")
    }
    missing = [str(path) for path in split_paths.values() if not path.is_file()]
    if missing:
        raise FileNotFoundError(
            "Cannot fingerprint the evaluation dataset; missing prepared split "
            f"files: {missing}. Prepare the dataset before evaluation."
        )
    split_sha256 = {split: _sha256(path) for split, path in split_paths.items()}

    requested_config_path = dataset_config.get("config_path")
    requested_config = None
    requested_config_sha256 = None
    if requested_config_path is not None:
        requested_path = Path(str(requested_config_path))
        if requested_path.is_file():
            requested_config = load_yaml(requested_path)
            requested_config_sha256 = _sha256(requested_path)

    resolved_path = directory / "resolved_dataset_config.yaml"
    resolved_config = load_yaml(resolved_path) if resolved_path.is_file() else None
    resolved_config_sha256 = _sha256(resolved_path) if resolved_path.is_file() else None
    protocol_id = None
    for candidate in (resolved_config, requested_config, dataset_config):
        if isinstance(candidate, dict) and candidate.get("protocol_id"):
            protocol_id = str(candidate["protocol_id"])
            break

    return {
        "benchmark_id": benchmark_id,
        "serialized_id": serialized_id,
        "root": str(root),
        "dataset_dir": str(directory),
        "protocol_id": protocol_id,
        "split_sizes": {
            split: len(list(splits.get(split, [])))
            for split in ("train", "val", "test")
        },
        "split_paths": {split: str(path) for split, path in split_paths.items()},
        "split_sha256": split_sha256,
        "fingerprint": _combined_split_fingerprint(split_sha256),
        "requested_config_path": (
            str(requested_config_path) if requested_config_path is not None else None
        ),
        "requested_config_sha256": requested_config_sha256,
        "resolved_config_path": str(resolved_path) if resolved_path.is_file() else None,
        "resolved_config_sha256": resolved_config_sha256,
    }


def _find_training_manifest(start: Path) -> tuple[dict[str, Any] | None, Path | None]:
    """Find the managed baseline training manifest associated with a generation."""

    start = start.expanduser().resolve(strict=False)
    candidates = [start if start.is_dir() else start.parent, *(start.parents)]
    seen: set[str] = set()
    for directory in candidates[:8]:
        candidate = directory / "train" / "manifest.json"
        key = str(candidate)
        if key in seen:
            continue
        seen.add(key)
        value = _load_json_mapping(candidate)
        if value is not None:
            return value, candidate
    return None, None


def _manifest_dataset_record(
    generation_manifest: dict[str, Any] | None,
    training_manifest: dict[str, Any] | None,
) -> dict[str, Any] | None:
    # Prefer the training manifest because it records the exact prepared-split
    # fingerprint; generation manifests may only carry the benchmark name.
    for manifest in (training_manifest, generation_manifest):
        if not isinstance(manifest, dict):
            continue
        dataset = manifest.get("dataset")
        if isinstance(dataset, dict):
            return dataset
    return None


def validate_dataset_compatibility(
    provenance: dict[str, Any],
    *,
    generation_manifest: dict[str, Any] | None,
    training_manifest: dict[str, Any] | None,
    mismatch_policy: str,
) -> list[str]:
    """Validate available generation/training provenance against current splits."""

    policy = str(mismatch_policy).strip().lower()
    if policy not in {"error", "warn", "ignore"}:
        raise ValueError(f"Unknown dataset mismatch policy: {mismatch_policy!r}")
    dataset_record = _manifest_dataset_record(generation_manifest, training_manifest)
    if dataset_record is None:
        return []

    mismatches: list[str] = []
    expected_benchmark = dataset_record.get("benchmark_id")
    if expected_benchmark is not None and str(expected_benchmark) != str(
        provenance["benchmark_id"]
    ):
        mismatches.append(
            "benchmark_id differs: generation/training="
            f"{expected_benchmark!r}, evaluation={provenance['benchmark_id']!r}"
        )

    expected_fingerprint = dataset_record.get("fingerprint")
    if expected_fingerprint is not None and str(expected_fingerprint) != str(
        provenance["fingerprint"]
    ):
        mismatches.append(
            "dataset split fingerprint differs: generation/training="
            f"{expected_fingerprint}, evaluation={provenance['fingerprint']}"
        )

    expected_split_hashes = dataset_record.get("split_sha256")
    if isinstance(expected_split_hashes, dict):
        for split in ("train", "val", "test"):
            expected = expected_split_hashes.get(split)
            observed = provenance["split_sha256"].get(split)
            if expected is not None and str(expected) != str(observed):
                mismatches.append(
                    f"{split} split SHA-256 differs: generation/training="
                    f"{expected}, evaluation={observed}"
                )

    if mismatches and policy == "error":
        detail = "\n  - ".join(mismatches)
        raise RuntimeError(
            "Generated graphs were trained/prepared against a different dataset "
            "than the one selected for evaluation:\n  - "
            + detail
            + "\nUse --dataset-mismatch-policy warn only for an intentional "
            "cross-dataset diagnostic."
        )
    if mismatches and policy == "warn":
        print("WARNING: dataset provenance mismatch detected:", flush=True)
        for mismatch in mismatches:
            print(f"  - {mismatch}", flush=True)
    return mismatches


def resolve_evaluation_counts(
    *,
    num_reference: int,
    num_generated: int,
    configured_reference_cap: int | None,
    max_generated_graphs: int | None,
) -> tuple[int, int]:
    """Keep the held-out reference fixed while optionally capping candidates."""

    reference_count = int(num_reference)
    if configured_reference_cap is not None and int(configured_reference_cap) > 0:
        reference_count = min(reference_count, int(configured_reference_cap))
    generated_count = int(num_generated)
    if max_generated_graphs is not None:
        cap = int(max_generated_graphs)
        if cap <= 0:
            raise ValueError("--max-graphs must be positive when provided.")
        generated_count = min(generated_count, cap)
    return reference_count, generated_count


def _print_dataset_provenance(provenance: dict[str, Any]) -> None:
    sizes = provenance["split_sizes"]
    print(
        "Dataset: "
        f"benchmark={provenance['benchmark_id']} "
        f"serialized={provenance['serialized_id']} "
        f"protocol={provenance['protocol_id'] or 'unspecified'}",
        flush=True,
    )
    print(
        "Dataset splits: "
        f"train={sizes['train']} val={sizes['val']} test={sizes['test']}",
        flush=True,
    )
    print(f"Dataset fingerprint: {provenance['fingerprint']}", flush=True)
    for split in ("train", "val", "test"):
        print(
            f"  {split} SHA256: {provenance['split_sha256'][split]}",
            flush=True,
        )


def _normalize_stage_label(value: str, *, field: str) -> str:
    """Convert a human/model label into a stable comparison-table token."""

    normalized = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(value).strip())
    normalized = (
        normalized.strip("_.-")
        .lower()
        .replace("-", "_")
        .replace(".", "_")
    )
    if not normalized:
        raise ValueError(f"{field} must contain at least one letter or digit.")
    return normalized


def _baseline_model_id(
    graph_path: Path,
    manifest: dict[str, Any] | None = None,
) -> str | None:
    """Infer a managed baseline model from its manifest or canonical path."""

    if manifest is None:
        manifest = _load_json_mapping(graph_path.parent / "manifest.json")
    if isinstance(manifest, dict) and manifest.get("model_id"):
        return _normalize_stage_label(
            str(manifest["model_id"]),
            field="generation manifest model_id",
        )

    parts = graph_path.expanduser().resolve(strict=False).parts
    lowered = [part.lower() for part in parts]
    if "baselines" in lowered:
        index = lowered.index("baselines")
        if index + 1 < len(parts):
            return _normalize_stage_label(parts[index + 1], field="baseline model")
    return None


def resolve_generated_graph_path(
    generated_dir: Path,
    *,
    generated_graphs: str | Path | None = None,
) -> tuple[Path, dict[str, Any] | None, Path | None]:
    """Resolve GraphER final outputs or a managed raw-baseline generation.

    Managed baseline wrappers publish ``base_graphs.pkl`` and ``manifest.json``
    in one generation directory.  GraphER correction runs instead publish
    ``topology_refined_graphs.pkl`` (or the historical hybrid alias).  This
    resolver supports both layouts without requiring callers to copy or rename
    the baseline batch.
    """

    generated_dir = Path(generated_dir)
    directory_manifest_path = generated_dir / "manifest.json"
    directory_manifest = _load_json_mapping(directory_manifest_path)

    if generated_graphs is not None:
        path = Path(generated_graphs)
        if not path.is_file():
            raise FileNotFoundError(f"Generated graph file does not exist: {path}")
        sibling_manifest_path = path.parent / "manifest.json"
        sibling_manifest = _load_json_mapping(sibling_manifest_path)
        if sibling_manifest is not None:
            return path, sibling_manifest, sibling_manifest_path
        if directory_manifest is not None:
            return path, directory_manifest, directory_manifest_path
        return path, None, None

    candidates: list[Path] = [
        generated_dir / "topology_refined_graphs.pkl",
        generated_dir / "hybrid_refined_graphs.pkl",
    ]
    if directory_manifest is not None:
        base_entry = directory_manifest.get("base_graphs")
        if isinstance(base_entry, dict) and base_entry.get("path"):
            manifest_graph_path = Path(str(base_entry["path"]))
            if not manifest_graph_path.is_absolute():
                manifest_graph_path = generated_dir / manifest_graph_path
            candidates.append(manifest_graph_path)
    candidates.append(generated_dir / "base_graphs.pkl")

    deduplicated: list[Path] = []
    seen: set[str] = set()
    for candidate in candidates:
        key = str(candidate.expanduser().resolve(strict=False))
        if key not in seen:
            deduplicated.append(candidate)
            seen.add(key)

    for candidate in deduplicated:
        if not candidate.is_file():
            continue
        sibling_manifest_path = candidate.parent / "manifest.json"
        sibling_manifest = _load_json_mapping(sibling_manifest_path)
        if sibling_manifest is not None:
            return candidate, sibling_manifest, sibling_manifest_path
        if directory_manifest is not None:
            return candidate, directory_manifest, directory_manifest_path
        return candidate, None, None

    attempted = "\n  - ".join(str(path) for path in deduplicated)
    raise FileNotFoundError(
        "Could not locate generated graphs. Checked:\n  - "
        + attempted
        + "\nPass --generated-graphs for a non-standard artifact path."
    )


def resolve_generated_stage(
    config: dict[str, Any],
    generated_path: Path,
    *,
    generation_manifest: dict[str, Any] | None = None,
    explicit_stage: str | None = None,
) -> str:
    """Choose the report row label for raw baselines or corrected outputs."""

    if explicit_stage is not None:
        return _normalize_stage_label(explicit_stage, field="--generated-stage")

    model_id = _baseline_model_id(generated_path, generation_manifest)
    if model_id is not None:
        return model_id

    pipeline_stage = str(
        (config.get("pipeline", {}) or {}).get("stage", "endpoint")
    ).lower()
    topology_stages = {"topology", "posthoc_correction", "topology_correction"}
    return "topology_final" if pipeline_stage in topology_stages else "hybrid_final"


def _same_artifact(left: Path | None, right: Path | None) -> bool:
    if left is None or right is None:
        return False
    return left.expanduser().resolve(strict=False) == right.expanduser().resolve(
        strict=False
    )


def resolve_base_graph_path(
    generated_dir: Path,
    *,
    base_graphs: str | Path | None = None,
    coarse_graphs: str | Path | None = None,
) -> tuple[Path | None, str | None]:
    """Resolve a saved source stage without mislabelling managed baselines."""

    if base_graphs is not None and coarse_graphs is not None:
        raise ValueError("Use --base-graphs or --coarse-graphs, not both.")
    if base_graphs is not None:
        path = Path(base_graphs)
        model_id = _baseline_model_id(path)
        return path, f"{model_id}_base" if model_id else "base"
    if coarse_graphs is not None:
        return Path(coarse_graphs), "hh_source"

    candidates = (
        (generated_dir / "defog_base_graphs.pkl", "defog_base"),
        (generated_dir / "base_graphs.pkl", None),
        (generated_dir / "coarse_graphs.pkl", "hh_source"),
    )
    for path, declared_stage in candidates:
        if not path.is_file():
            continue
        if declared_stage is not None:
            return path, declared_stage
        model_id = _baseline_model_id(path)
        return path, f"{model_id}_base" if model_id else "base"
    return None, None


def _paper_mmd(
    reference: Sequence[nx.Graph],
    candidate: Sequence[nx.Graph],
    *,
    compute_orbit: bool = True,
    metric_protocol: str = "graphrnn",
    clustering_bins: int = 100,
) -> dict[str, float]:
    """Evaluate generic graph statistics under a declared metric protocol.

    ``graphrnn`` reproduces the historical GraphRNN/SPECTRE convention used
    by GraphRNN, HOG-Diff (Community/Ego), and DiGress/DeFoG Comm20:

    * degree histogram + Gaussian EMD, sigma=1;
    * 100-bin clustering histogram + Gaussian EMD, sigma=0.1, distance
      scaling equal to the number of bins; and
    * mean per-node four-node orbit vector + Gaussian L2, sigma=30.

    ``graphes_adaptive`` keeps the pre-alignment GraphES behavior for
    backwards diagnostics only.
    """

    protocol = str(metric_protocol).strip().lower().replace("-", "_")
    max_degree = max(
        (
            max((int(degree) for _, degree in graph.degree()), default=0)
            for graph in [*reference, *candidate]
        ),
        default=0,
    )
    degree_reference = descriptor_matrix(
        reference,
        lambda graph: degree_histogram(graph, max_degree),
    )
    degree_candidate = descriptor_matrix(
        candidate,
        lambda graph: degree_histogram(graph, max_degree),
    )

    if protocol in {"graphrnn", "graphrnn_legacy", "spectre", "spectre_legacy"}:
        bins = int(clustering_bins)
        if bins <= 0:
            raise ValueError("clustering_bins must be positive.")
        clustering_reference = descriptor_matrix(
            reference,
            lambda graph: clustering_histogram(graph, bins),
        )
        clustering_candidate = descriptor_matrix(
            candidate,
            lambda graph: clustering_histogram(graph, bins),
        )
        return {
            "degree_mmd": mmd_gaussian_emd(
                degree_reference, degree_candidate, sigma=1.0
            ),
            "clustering_mmd": mmd_gaussian_emd(
                clustering_reference,
                clustering_candidate,
                sigma=0.1,
                distance_scaling=float(bins),
            ),
            "orbit_mmd": (
                mmd_orbit_graphrnn(reference, candidate, sigma=30.0)
                if compute_orbit
                else float("nan")
            ),
        }

    if protocol in {"graphes_adaptive", "adaptive"}:
        clustering_reference = descriptor_matrix(
            reference,
            lambda graph: clustering_histogram(graph, 20),
        )
        clustering_candidate = descriptor_matrix(
            candidate,
            lambda graph: clustering_histogram(graph, 20),
        )
        return {
            "degree_mmd": mmd_gaussian_emd(degree_reference, degree_candidate),
            "clustering_mmd": mmd_gaussian_emd(
                clustering_reference, clustering_candidate
            ),
            "orbit_mmd": (
                mmd_orbit(reference, candidate)
                if compute_orbit
                else float("nan")
            ),
        }

    raise ValueError(
        f"Unknown generic MMD protocol {metric_protocol!r}; expected "
        "'graphrnn' or 'graphes_adaptive'."
    )


def is_molecular_evaluation(
    dataset_config: dict[str, Any],
    graphs: Sequence[nx.Graph],
) -> bool:
    """Detect an attributed molecular dataset without relying on its name alone."""

    dataset_name = str(dataset_config.get("name", "")).lower()
    if any(token in dataset_name for token in ("qm9", "zinc", "molecule")):
        return True
    return any(
        "atomic_num" in data or "atom_type" in data
        for graph in graphs
        for _, data in graph.nodes(data=True)
    )


def _canonical_molecular_smiles(
    graph: nx.Graph,
) -> tuple[str | None, str | None]:
    """Return an RDKit-sanitized canonical SMILES and any conversion error."""

    if graph.number_of_nodes() == 0:
        return None, "EmptyMolecule"
    if any(
        "atomic_num" not in data and "atom_type" not in data
        for _, data in graph.nodes(data=True)
    ):
        return None, "MissingAtomType"
    if any(
        "bond_type" not in data and "bond_order" not in data
        for _, _, data in graph.edges(data=True)
    ):
        return None, "MissingBondType"
    Chem = require_rdkit()
    try:
        molecule = nx_to_rdkit_mol(graph, sanitize=True)
        smiles = str(
            Chem.MolToSmiles(
                molecule,
                canonical=True,
                isomericSmiles=False,
            )
        )
        if not smiles:
            return None, "EmptySMILES"
        return smiles, None
    except Exception as exc:
        return None, type(exc).__name__


def molecular_quality_metrics(
    generated_graphs: Sequence[nx.Graph],
    train_graphs: Sequence[nx.Graph],
) -> tuple[dict[str, Any], list[str], list[int], dict[str, int]]:
    """Compute RDKit validity, canonical-SMILES uniqueness, and novelty."""

    # Fail early with the existing installation guidance when RDKit is absent.
    require_rdkit()

    valid_smiles: list[str] = []
    invalid_indices: list[int] = []
    conversion_errors: Counter[str] = Counter()
    for index, graph in enumerate(generated_graphs):
        smiles, error = _canonical_molecular_smiles(graph)
        if smiles is None:
            invalid_indices.append(index)
            conversion_errors[str(error or "InvalidMolecule")] += 1
        else:
            valid_smiles.append(smiles)

    train_smiles = {
        smiles
        for graph in train_graphs
        if (smiles := _canonical_molecular_smiles(graph)[0]) is not None
    }
    unique_valid_smiles = sorted(set(valid_smiles))
    novel_smiles = [
        smiles for smiles in unique_valid_smiles if smiles not in train_smiles
    ]

    num_generated = len(generated_graphs)
    num_valid = len(valid_smiles)
    num_unique = len(unique_valid_smiles)
    novelty_rate: float | None
    if not train_smiles:
        novelty_rate = None
    elif num_unique == 0:
        novelty_rate = 0.0
    else:
        novelty_rate = len(novel_smiles) / num_unique

    metrics = {
        "num_generated_graphs": num_generated,
        "num_valid_generated_molecules": num_valid,
        "num_invalid_generated_molecules": num_generated - num_valid,
        "validity_without_correction": num_valid / max(num_generated, 1),
        "unique_valid_count": num_unique,
        "uniqueness_rate": num_unique / max(num_valid, 1),
        "num_valid_training_molecules": len(train_smiles),
        "novel_unique_valid_count": len(novel_smiles),
        "novelty_rate": novelty_rate,
    }
    return (
        metrics,
        valid_smiles,
        invalid_indices,
        dict(conversion_errors),
    )


def select_sample_indices(
    graphs: Sequence[nx.Graph],
    count: int,
    *,
    selection: str,
    seed: int,
) -> list[int]:
    count = min(max(int(count), 0), len(graphs))
    if count == 0:
        return []
    if selection == "random":
        rng = np.random.default_rng(seed)
        return sorted(
            int(index) for index in rng.choice(len(graphs), size=count, replace=False)
        )
    if selection != "stratified":
        raise ValueError(f"Unknown sample selection: {selection!r}.")

    # Cover the generated size range rather than showing only the first graphs.
    ordered = sorted(
        range(len(graphs)),
        key=lambda index: (
            graphs[index].number_of_nodes(),
            graphs[index].number_of_edges(),
            index,
        ),
    )
    positions = np.linspace(0, len(ordered) - 1, num=count)
    return [ordered[int(round(position))] for position in positions]


def _atomic_number(data: dict[str, Any]) -> int | None:
    value = data.get("atomic_num", data.get("atom_type"))
    return int(value) if value is not None else None


def _draw_graph(
    axis: Any,
    graph: nx.Graph,
    *,
    graph_index: int,
    layout_seed: int,
) -> bool:
    molecular = any(
        _atomic_number(data) is not None for _, data in graph.nodes(data=True)
    )
    positions = nx.spring_layout(
        graph,
        seed=int(layout_seed + graph_index),
        iterations=150,
    )
    node_colors = []
    labels: dict[Any, str] = {}
    for node, data in graph.nodes(data=True):
        atomic_number = _atomic_number(data)
        node_colors.append(
            ATOM_COLORS.get(atomic_number, "#60A5FA") if molecular else "#4C78A8"
        )
        if molecular and atomic_number is not None:
            labels[node] = ATOM_LABELS.get(atomic_number, str(atomic_number))

    edge_widths = []
    edge_colors = []
    for _, _, data in graph.edges(data=True):
        bond_type = int(data.get("bond_type", 1))
        edge_widths.append({1: 1.4, 2: 2.4, 3: 3.4, 4: 2.0}.get(bond_type, 1.4))
        edge_colors.append("#7C3AED" if bond_type == 4 else "#6B7280")

    node_size = max(90, min(360, int(9000 / max(graph.number_of_nodes(), 1))))
    nx.draw_networkx_edges(
        graph,
        positions,
        ax=axis,
        width=edge_widths,
        edge_color=edge_colors,
        alpha=0.8,
    )
    nx.draw_networkx_nodes(
        graph,
        positions,
        ax=axis,
        node_color=node_colors,
        node_size=node_size,
        edgecolors="#111827",
        linewidths=0.6,
    )
    if labels:
        nx.draw_networkx_labels(
            graph,
            positions,
            labels=labels,
            ax=axis,
            font_size=8,
            font_color="white",
        )
    axis.set_title(
        f"Sample {graph_index + 1}\n"
        f"$|V|={graph.number_of_nodes()}$, $|E|={graph.number_of_edges()}$",
        fontsize=9,
    )
    axis.set_axis_off()
    return molecular


def plot_generated_graphs(
    graphs: Sequence[nx.Graph],
    indices: Sequence[int],
    *,
    output_png: Path,
    output_pdf: Path,
    columns: int,
    layout_seed: int,
    dpi: int,
) -> None:
    if not indices:
        raise ValueError("At least one generated graph is required for plotting.")
    columns = max(1, min(int(columns), len(indices)))
    rows = int(np.ceil(len(indices) / columns))
    figure, axes = plt.subplots(
        rows,
        columns,
        figsize=(3.2 * columns, 3.0 * rows),
        squeeze=False,
    )
    molecular = False
    for axis, index in zip(axes.flat, indices):
        molecular = (
            _draw_graph(
                axis,
                graphs[index],
                graph_index=index,
                layout_seed=layout_seed,
            )
            or molecular
        )
    for axis in axes.flat[len(indices) :]:
        axis.set_axis_off()
    if molecular:
        atoms_present = sorted(
            {
                atomic_number
                for index in indices
                for _, data in graphs[index].nodes(data=True)
                if (atomic_number := _atomic_number(data)) is not None
            }
        )
        handles = [
            Line2D(
                [0],
                [0],
                marker="o",
                color="none",
                markerfacecolor=ATOM_COLORS.get(atomic_number, "#60A5FA"),
                markeredgecolor="#111827",
                label=ATOM_LABELS.get(atomic_number, str(atomic_number)),
                markersize=8,
            )
            for atomic_number in atoms_present
        ]
        figure.legend(
            handles=handles,
            loc="lower center",
            ncol=max(1, len(handles)),
            frameon=False,
        )
        figure.subplots_adjust(bottom=0.09)
    figure.suptitle("Representative generated graphs", fontsize=13)
    figure.tight_layout(rect=(0, 0.04 if molecular else 0, 1, 0.96))
    output_png.parent.mkdir(parents=True, exist_ok=True)
    figure.savefig(output_png, dpi=dpi, bbox_inches="tight")
    figure.savefig(output_pdf, bbox_inches="tight")
    plt.close(figure)


def _write_csv(rows: Sequence[dict[str, Any]], path: Path) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=("comparison", *REPORT_METRICS),
        )
        writer.writeheader()
        writer.writerows(rows)


def _write_molecular_csv(
    rows: Sequence[dict[str, Any]],
    path: Path,
) -> None:
    fieldnames: list[str] = []
    for row in rows:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(key)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=tuple(fieldnames))
        writer.writeheader()
        writer.writerows(rows)


def resolve_reference_split(
    config: dict[str, Any], explicit_split: str | None = None,
) -> str:
    """CLI overrides evaluation.reference_split; legacy configs default to test.

    protocol.tune_on_split is intentionally not treated as a CLI instruction.
    """
    value = explicit_split
    if value is None:
        value = (config.get("evaluation", {}) or {}).get("reference_split", "test")
    split = str(value).strip().lower()
    if split not in {"val", "test"}:
        raise ValueError("evaluation.reference_split must be 'val' or 'test'.")
    return split


def validate_report_reference_split(output_dir: Path, reference_split: str) -> None:
    """Prevent validation and test reports from silently overwriting one another."""
    report = _load_json_mapping(output_dir / "graph_evaluation_report.json")
    if report is not None and report.get("reference_split", "test") != reference_split:
        raise ValueError(
            "This output directory already contains a report for a different "
            "reference split. Use separate --output-dir paths for validation "
            "and test (for example evaluation_val and evaluation_test)."
        )


def _print_table(rows: Sequence[dict[str, Any]], *, reference_split: str = "test") -> None:
    print(f"Graph-distribution MMD against held-out {reference_split} graphs (lower is better)")
    print(
        f"{'Comparison':30s}"
        f"{'Degree MMD':>14s}"
        f"{'Clustering MMD':>18s}"
        f"{'Orbit MMD':>14s}"
    )
    for row in rows:
        print(
            f"{str(row['comparison']):30s}"
            f"{float(row['degree_mmd']):14.6f}"
            f"{float(row['clustering_mmd']):18.6f}"
            f"{float(row['orbit_mmd']):14.6f}"
        )


def _print_molecular_metrics(rows: Sequence[dict[str, Any]]) -> None:
    print("\nMolecular quality by stage (RDKit; higher is better)")
    print(
        f"{'Stage':24s}"
        f"{'Validity':>12s}"
        f"{'Uniqueness':>14s}"
        f"{'Novelty':>12s}"
        f"{'Valid count':>16s}"
    )
    for row in rows:
        novelty = row["novelty_rate"]
        novelty_text = "n/a" if novelty is None else f"{float(novelty):.6f}"
        count = f"{row['num_valid_generated_molecules']}/{row['num_generated_graphs']}"
        print(
            f"{str(row['stage']):24s}"
            f"{float(row['validity_without_correction']):12.6f}"
            f"{float(row['uniqueness_rate']):14.6f}"
            f"{novelty_text:>12s}"
            f"{count:>16s}"
        )


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Evaluate saved generated graphs with degree and clustering MMD, "
            "optionally add four-node ORCA orbit MMD, then plot "
            "representative samples."
        )
    )
    parser.add_argument("--config", required=True)
    parser.add_argument(
        "--reference-split", choices=("val", "test"), default=None,
        help=("Reference graphs for all MMD rows. Overrides evaluation.reference_split; "
              "legacy configs default to test. Use val for weight selection."),
    )
    parser.add_argument(
        "--generic-mmd-protocol",
        choices=("config", "graphrnn", "graphes_adaptive"),
        default="config",
        help=(
            "Generic-graph MMD convention. 'config' reads "
            "evaluation.generic_mmd_protocol (default: graphrnn)."
        ),
    )
    parser.add_argument("--generated-dir", required=True)
    parser.add_argument(
        "--generated-graphs",
        default=None,
        help=(
            "Optional explicit graph pickle. When omitted, the evaluator "
            "auto-detects GraphER refined outputs or a managed baseline "
            "generation's base_graphs.pkl."
        ),
    )
    parser.add_argument(
        "--generated-stage",
        default=None,
        help=(
            "Optional comparison-row stage label, for example 'defog_800k'. "
            "Managed baseline model IDs are inferred from manifest.json when "
            "this option is omitted."
        ),
    )
    parser.add_argument("--base-graphs", default=None)
    parser.add_argument("--coarse-graphs", default=None)
    parser.add_argument("--output-dir", default=None)
    parser.add_argument(
        "--max-graphs",
        type=int,
        default=None,
        help=(
            "Cap generated/source candidate graphs only. The selected held-out "
            "reference remains fixed; use protocol.max_reference_graphs in "
            "the config to cap the reference set explicitly."
        ),
    )
    parser.add_argument(
        "--dataset-mismatch-policy",
        choices=("error", "warn", "ignore"),
        default="error",
        help=(
            "Behavior when managed generation/training provenance identifies "
            "different prepared dataset splits. Default: error."
        ),
    )
    parser.add_argument(
        "--build-dataset-if-missing",
        action="store_true",
        help=(
            "Opt in to rebuilding missing prepared dataset splits during "
            "evaluation. By default evaluation fails instead of silently "
            "creating a new reference dataset."
        ),
    )
    parser.add_argument("--num-samples", type=int, default=8)
    parser.add_argument(
        "--sample-selection",
        choices=("stratified", "random"),
        default="stratified",
    )
    parser.add_argument("--sample-seed", type=int, default=42)
    parser.add_argument("--layout-seed", type=int, default=42)
    parser.add_argument("--columns", type=int, default=4)
    parser.add_argument("--dpi", type=int, default=300)
    args = parser.parse_args()

    config = load_yaml(args.config)
    reference_split = resolve_reference_split(config, args.reference_split)
    generated_dir = Path(args.generated_dir)
    (
        generated_path,
        generation_manifest,
        generation_manifest_path,
    ) = resolve_generated_graph_path(
        generated_dir,
        generated_graphs=args.generated_graphs,
    )
    base_path, base_stage = resolve_base_graph_path(
        generated_dir,
        base_graphs=args.base_graphs,
        coarse_graphs=args.coarse_graphs,
    )
    # A managed raw baseline stores its evaluated batch as base_graphs.pkl.
    # Do not evaluate the same artifact twice as both the source and final row.
    if _same_artifact(base_path, generated_path):
        base_path, base_stage = None, None
    default_output_name = "evaluation_report" if reference_split == "test" else "evaluation_report_val"
    output_dir = ensure_dir(args.output_dir or generated_dir / default_output_name)
    validate_report_reference_split(output_dir, reference_split)

    evaluation_cfg = config.get("evaluation", {}) or {}
    generic_mmd_protocol = (
        str(evaluation_cfg.get("generic_mmd_protocol", "graphrnn"))
        if args.generic_mmd_protocol == "config"
        else str(args.generic_mmd_protocol)
    )
    generic_clustering_bins = int(
        evaluation_cfg.get("generic_clustering_bins", 100)
    )
    compute_orbit = bool(evaluation_cfg.get("compute_orbit", True))
    graphlet_backend = str(
        evaluation_cfg.get("graphlet_backend", "sampled")
    ).lower()
    exact_orca_backend = graphlet_backend in {
        "orca",
        "exact_orca",
        "exact",
    }
    orca_required = compute_orbit and exact_orca_backend
    orca_exec = (
        configure_orca_executable(
            evaluation_cfg.get("orca_exec"),
            required=orca_required,
        )
        if compute_orbit
        else None
    )
    if orca_exec:
        print(f"ORCA orbit evaluation enabled: {orca_exec}", flush=True)
    elif compute_orbit:
        print("Python four-node orbit evaluation enabled.", flush=True)
    else:
        print("ORCA evaluation disabled by configuration.", flush=True)

    print(
        "Generic MMD protocol: "
        f"{generic_mmd_protocol} (clustering_bins={generic_clustering_bins})",
        flush=True,
    )

    dataset_cfg = config.get("dataset", {}) or {}
    splits = load_dataset_splits(
        str(dataset_cfg.get("name", "sbm")),
        root=dataset_cfg.get("root", "outputs/datasets"),
        build_if_missing=bool(args.build_dataset_if_missing),
        config_path=dataset_cfg.get("config_path"),
    )
    train_graphs = list(splits.get("train", []))
    reference_graphs = list(splits.get(reference_split, []))
    provenance = dataset_provenance(dataset_cfg, splits)
    _print_dataset_provenance(provenance)
    training_manifest, training_manifest_path = _find_training_manifest(
        generated_path.parent
    )
    dataset_mismatches = validate_dataset_compatibility(
        provenance,
        generation_manifest=generation_manifest,
        training_manifest=training_manifest,
        mismatch_policy=args.dataset_mismatch_policy,
    )
    if training_manifest_path is not None:
        print(f"Training manifest: {training_manifest_path}", flush=True)
    generated_graphs = _load_graph_list(generated_path)
    base_graphs = (
        _load_graph_list(base_path)
        if base_path is not None and base_path.is_file()
        else []
    )
    enriched_base_path = generated_dir / "enriched_base_graphs.pkl"
    enriched_base_graphs = (
        _load_graph_list(enriched_base_path)
        if enriched_base_path.is_file()
        else []
    )
    if not reference_graphs:
        raise ValueError(f"The configured dataset has no {reference_split} graphs.")

    protocol_cfg = config.get("protocol", {}) or {}
    configured_reference_cap = protocol_cfg.get("max_reference_graphs")
    reference_count, generated_count = resolve_evaluation_counts(
        num_reference=len(reference_graphs),
        num_generated=len(generated_graphs),
        configured_reference_cap=(
            int(configured_reference_cap)
            if configured_reference_cap is not None
            else None
        ),
        max_generated_graphs=args.max_graphs,
    )
    if reference_count <= 0:
        raise ValueError("No held-out reference graphs are available.")
    if generated_count <= 0:
        raise ValueError("No generated graphs are available.")
    reference = reference_graphs[:reference_count]
    generated = generated_graphs[:generated_count]
    molecular = is_molecular_evaluation(dataset_cfg, generated_graphs)
    final_stage = resolve_generated_stage(
        config,
        generated_path,
        generation_manifest=generation_manifest,
        explicit_stage=args.generated_stage,
    )
    print(f"Generated graph input: {generated_path}", flush=True)
    if generation_manifest_path is not None:
        print(
            f"Generation manifest: {generation_manifest_path}",
            flush=True,
        )
    print(f"Generated stage label: {final_stage}", flush=True)
    print(
        f"Evaluation counts: reference_{reference_split}={len(reference)} "
        f"generated={len(generated)} train_reference={len(train_graphs)}",
        flush=True,
    )

    rows: list[dict[str, Any]] = []
    if train_graphs:
        rows.append(
            {
                "comparison": f"train_to_{reference_split}",
                **_paper_mmd(
                    reference,
                    train_graphs,
                    compute_orbit=compute_orbit,
                    metric_protocol=generic_mmd_protocol,
                    clustering_bins=generic_clustering_bins,
                ),
            }
        )
    if base_graphs:
        base_count = len(base_graphs)
        if args.max_graphs is not None:
            base_count = min(base_count, int(args.max_graphs))
        rows.append(
            {
                "comparison": f"{base_stage}_to_{reference_split}",
                **_paper_mmd(
                    reference,
                    base_graphs[:base_count],
                    compute_orbit=compute_orbit,
                    metric_protocol=generic_mmd_protocol,
                    clustering_bins=generic_clustering_bins,
                ),
            }
        )
    if enriched_base_graphs and not _same_artifact(enriched_base_path, generated_path):
        enriched_count = len(enriched_base_graphs)
        if args.max_graphs is not None:
            enriched_count = min(enriched_count, int(args.max_graphs))
        rows.append(
            {
                "comparison": f"enriched_base_to_{reference_split}",
                **_paper_mmd(
                    reference,
                    enriched_base_graphs[:enriched_count],
                    compute_orbit=compute_orbit,
                    metric_protocol=generic_mmd_protocol,
                    clustering_bins=generic_clustering_bins,
                ),
            }
        )
    rows.append(
        {
            "comparison": f"{final_stage}_to_{reference_split}",
            **_paper_mmd(
                reference,
                generated,
                compute_orbit=compute_orbit,
                metric_protocol=generic_mmd_protocol,
                clustering_bins=generic_clustering_bins,
            ),
        }
    )

    indices = select_sample_indices(
        generated,
        args.num_samples,
        selection=args.sample_selection,
        seed=args.sample_seed,
    )
    png_path = output_dir / "generated_graph_samples.png"
    pdf_path = output_dir / "generated_graph_samples.pdf"
    csv_path = output_dir / "graph_mmd_metrics.csv"
    json_path = output_dir / "graph_evaluation_report.json"
    molecular_csv_path = output_dir / "molecular_quality_metrics.csv"
    valid_smiles_path = output_dir / "valid_generated.smi"
    plot_generated_graphs(
        generated,
        indices,
        output_png=png_path,
        output_pdf=pdf_path,
        columns=args.columns,
        layout_seed=args.layout_seed,
        dpi=args.dpi,
    )
    _write_csv(rows, csv_path)
    molecular_metrics: dict[str, Any] | None = None
    molecular_stage_rows: list[dict[str, Any]] = []
    molecular_stage_errors: dict[str, dict[str, int]] = {}
    invalid_molecule_indices: list[int] = []
    conversion_error_counts: dict[str, int] = {}
    if molecular:
        stage_graphs: list[tuple[str, Sequence[nx.Graph]]] = [
            (f"real_{reference_split}", reference),
        ]
        if base_graphs:
            base_count = len(base_graphs)
            if args.max_graphs is not None:
                base_count = min(base_count, int(args.max_graphs))
            stage_graphs.append((str(base_stage), base_graphs[:base_count]))
        stage_graphs.append((final_stage, generated))
        valid_smiles: list[str] = []
        for stage, graphs in stage_graphs:
            (
                stage_metrics,
                stage_smiles,
                stage_invalid_indices,
                stage_errors,
            ) = molecular_quality_metrics(graphs, train_graphs)
            molecular_stage_rows.append({"stage": stage, **stage_metrics})
            molecular_stage_errors[stage] = stage_errors
            if stage == final_stage:
                molecular_metrics = stage_metrics
                valid_smiles = stage_smiles
                invalid_molecule_indices = stage_invalid_indices
                conversion_error_counts = stage_errors
        _write_molecular_csv(molecular_stage_rows, molecular_csv_path)
        with valid_smiles_path.open("w", encoding="utf-8") as handle:
            for smiles in valid_smiles:
                handle.write(smiles + "\n")

    save_json(
        {
            "format": "graph_generation_evaluation_report_v5",
            "reference_split": reference_split,
            "reference_split_sha256": provenance["split_sha256"][reference_split],
            "reference_graph_indices_zero_based": list(range(reference_count)),
            "orca_exec": orca_exec,
            "compute_orbit": compute_orbit,
            "generic_mmd_protocol": generic_mmd_protocol,
            "generic_clustering_bins": generic_clustering_bins,
            "graphlet_backend": graphlet_backend,
            "dataset_provenance": provenance,
            "dataset_mismatch_policy": args.dataset_mismatch_policy,
            "dataset_provenance_mismatches": dataset_mismatches,
            "training_manifest": (
                str(training_manifest_path)
                if training_manifest_path is not None
                else None
            ),
            "generated_graphs": str(generated_path),
            "generated_stage": final_stage,
            "generation_manifest": (
                str(generation_manifest_path)
                if generation_manifest_path is not None
                else None
            ),
            "generation_manifest_format": (
                generation_manifest.get("format")
                if generation_manifest is not None
                else None
            ),
            "generation_model_id": (
                generation_manifest.get("model_id")
                if generation_manifest is not None
                else None
            ),
            "base_graphs": str(base_path) if base_path is not None else None,
            "base_stage": base_stage,
            "num_graphs_evaluated": len(generated),
            "num_reference_graphs": len(reference),
            "num_generated_graphs_evaluated": len(generated),
            "metrics": rows,
            "molecular_evaluation": molecular,
            "molecular_quality": molecular_metrics,
            "molecular_quality_by_stage": {
                str(row["stage"]): {
                    key: value for key, value in row.items() if key != "stage"
                }
                for row in molecular_stage_rows
            },
            "molecular_protocol": (
                {
                    "validity_without_correction": (
                        "RDKit molecule construction followed by "
                        "Chem.SanitizeMol, without valency correction or "
                        "edge resampling."
                    ),
                    "uniqueness": (
                        "unique valid canonical SMILES / valid generated molecules"
                    ),
                    "novelty": (
                        "unique valid generated canonical SMILES absent from "
                        "the complete training split / unique valid generated "
                        "canonical SMILES"
                    ),
                    "canonical_smiles": True,
                    "isomeric_smiles": False,
                }
                if molecular
                else None
            ),
            "invalid_molecule_indices_zero_based": invalid_molecule_indices,
            "molecular_conversion_error_counts": conversion_error_counts,
            "molecular_conversion_error_counts_by_stage": (
                molecular_stage_errors if molecular else None
            ),
            "sample_selection": args.sample_selection,
            "sample_indices_zero_based": indices,
            "sample_figure_png": str(png_path),
            "sample_figure_pdf": str(pdf_path),
        },
        json_path,
    )
    _print_table(rows, reference_split=reference_split)
    if molecular_metrics is not None:
        _print_molecular_metrics(molecular_stage_rows)
    print(f"Saved metrics: {csv_path}")
    if molecular_metrics is not None:
        print(f"Saved metrics: {molecular_csv_path}")
        print(f"Saved SMILES:  {valid_smiles_path}")
    print(f"Saved report:  {json_path}")
    print(f"Saved figure:  {png_path}")
    print(f"Saved figure:  {pdf_path}")


if __name__ == "__main__":
    main()
