from __future__ import annotations

from pathlib import Path
from typing import Any, Sequence

import torch
from torch import nn
from torch.nn import functional as F

from grapher.rewiring_mlp.generic.cycle_graphlets import validate_cycle_graphlet_k
from grapher.rewiring_mlp.generic.induced_graphlets import (
    InducedGraphletSpec, InducedGraphletCollectionSpec,
    prediction_and_loss as induced_prediction_loss, mask_prediction,
    block_softmax as induced_block_softmax,
)
from grapher.properties.summary import SummaryConfig
from grapher.rewiring_mlp.generic.basis import TopologyGraphletBasis
from grapher.rewiring_mlp.generic.layers import TopologyMPNNLayer
from grapher.rewiring_mlp.generic.spectral_data import TopologySpectralBatch
from grapher.utils.device import resolve_torch_device
from grapher.utils.io import ensure_dir

TOPOLOGY_SPECTRAL_CHECKPOINT_FORMAT = "topology_spectral_transformer_v2"
TOPOLOGY_SPECTRAL_GRAPHLET_CHECKPOINT_FORMAT = "topology_spectral_graphlet_transformer_v2"


class TopologySpectralTransformerPredictor(nn.Module):
    """Predict the complete clean Laplacian spectrum in one forward pass.

    The graph encoder provides permutation-invariant context.  One spectral
    token is constructed for each *ordered* current eigenvalue and all tokens
    are processed jointly by a Transformer encoder.  The shared token head
    predicts eigenvalue gaps in parallel.  Positive gaps plus a trace
    normalization guarantee:

      lambda_1 = 0,
      lambda_1 <= ... <= lambda_n,
      sum_i lambda_i = 2m.

    Padding is masked, so the same checkpoint handles variable graph sizes.
    Eigenvectors are intentionally neither predicted nor constrained.
    """

    def __init__(
        self,
        *,
        hidden_dim: int = 128,
        edge_dim: int = 64,
        graph_dim: int = 128,
        num_layers: int = 4,
        spectral_dim: int = 128,
        spectral_layers: int = 3,
        spectral_heads: int = 4,
        spectral_ff_dim: int = 256,
        dropout: float = 0.0,
        min_gap: float = 1.0e-6,
        input_normalization: str = "mean_degree",
        use_graph_context: bool = True,
        predict_clustering_coefficient: bool = False,
        predict_clustering_histogram: bool = False,
        clustering_histogram_bins: int = 100,
        predict_orbit_summary: bool = False,
        orbit_summary_width: int = 15,
        predict_cycle_graphlet_histogram: bool = False,
        cycle_graphlet_k: int = 3,
        predict_induced_graphlet_histogram: bool = False,
        induced_graphlet_k: int = 5,
        induced_graphlet_k_min: int | None = None,
        induced_graphlet_k_max: int | None = None,
        induced_graphlet_scope: str = "all",
        induced_graphlet_catalogue_fingerprint: str | None = None,
        predict_edge_state: bool = False,
        edge_smoothing: float = 0.01,
    ) -> None:
        super().__init__()
        self.hidden_dim = int(hidden_dim)
        self.edge_dim = int(edge_dim)
        self.graph_dim = int(graph_dim)
        self.num_layers = int(num_layers)
        self.spectral_dim = int(spectral_dim)
        self.spectral_layers = int(spectral_layers)
        self.spectral_heads = int(spectral_heads)
        self.spectral_ff_dim = int(spectral_ff_dim)
        self.dropout_p = float(dropout)
        self.min_gap = float(min_gap)
        self.input_normalization = str(input_normalization).lower()
        self.use_graph_context = bool(use_graph_context)
        self.predict_clustering_coefficient = bool(predict_clustering_coefficient)
        self.predict_clustering_histogram = bool(predict_clustering_histogram)
        self.predict_orbit_summary = bool(predict_orbit_summary)
        self.predict_cycle_graphlet_histogram = bool(predict_cycle_graphlet_histogram)
        self.cycle_graphlet_k = validate_cycle_graphlet_k(cycle_graphlet_k)
        self.predict_induced_graphlet_histogram = bool(predict_induced_graphlet_histogram)
        if induced_graphlet_k_min is not None or induced_graphlet_k_max is not None:
            k_min = int(induced_graphlet_k if induced_graphlet_k_min is None else induced_graphlet_k_min)
            k_max = int(induced_graphlet_k if induced_graphlet_k_max is None else induced_graphlet_k_max)
            self.induced_graphlet_spec = (InducedGraphletSpec(k_min, induced_graphlet_scope)
                if k_min == k_max else InducedGraphletCollectionSpec(tuple(range(k_min, k_max + 1)), induced_graphlet_scope))
        else:
            self.induced_graphlet_spec = InducedGraphletSpec(induced_graphlet_k, induced_graphlet_scope)
        self.induced_graphlet_k = self.induced_graphlet_spec.k
        self.induced_graphlet_k_min = self.induced_graphlet_spec.min_k
        self.induced_graphlet_k_max = self.induced_graphlet_spec.max_k
        self.induced_graphlet_scope = self.induced_graphlet_spec.scope
        self.predict_edge_state = bool(predict_edge_state)
        self.edge_smoothing = float(edge_smoothing)
        if not 0.0 < self.edge_smoothing < 0.5:
            raise ValueError("edge_smoothing must be in (0,0.5).")
        fingerprint = self.induced_graphlet_spec.metadata()["fingerprint"]
        if induced_graphlet_catalogue_fingerprint not in (None, fingerprint):
            raise ValueError("Induced graphlet checkpoint catalogue fingerprint mismatch.")
        if (
            isinstance(clustering_histogram_bins, bool)
            or int(clustering_histogram_bins) != clustering_histogram_bins
            or int(clustering_histogram_bins) < 2
        ):
            raise ValueError("clustering_histogram_bins must be an integer >= 2.")
        self.clustering_histogram_bins = int(clustering_histogram_bins)
        if isinstance(orbit_summary_width, bool) or int(orbit_summary_width) != orbit_summary_width:
            raise ValueError("orbit_summary_width must be an integer.")
        self.orbit_summary_width = int(orbit_summary_width)
        if self.predict_orbit_summary and self.orbit_summary_width != 15:
            raise ValueError("The spectral debug model supports the standard 15-D ORCA orbit summary only.")

        if self.spectral_dim <= 0 or self.spectral_heads <= 0:
            raise ValueError("spectral_dim and spectral_heads must be positive.")
        if self.spectral_dim % self.spectral_heads != 0:
            raise ValueError("spectral_dim must be divisible by spectral_heads.")
        if self.spectral_layers <= 0 or self.num_layers <= 0:
            raise ValueError("Graph and spectral layer counts must be positive.")
        if self.spectral_ff_dim <= 0:
            raise ValueError("spectral_ff_dim must be positive.")
        if self.min_gap < 0.0:
            raise ValueError("min_gap must be nonnegative.")
        if self.input_normalization not in {
            "mean_degree",
            "average_degree",
            "avg_degree",
            "trace",
            "degree_sum",
            "none",
            "raw",
        }:
            raise ValueError(
                "input_normalization must be mean_degree, trace, or none."
            )

        # Same topology-state encoder family as the maintained structural model.
        self.node_in = nn.Linear(4, self.hidden_dim)
        # Legacy checkpoints use seven hard-source pair features. New joint edge
        # diffusion adds current soft edge probability and source edge probability.
        self.edge_in = nn.Linear(9 if self.predict_edge_state else 7, self.edge_dim)
        self.layers = nn.ModuleList(
            [
                TopologyMPNNLayer(self.hidden_dim, self.edge_dim)
                for _ in range(self.num_layers)
            ]
        )
        self.dropout = nn.Dropout(self.dropout_p)
        self.graph_encoder = nn.Sequential(
            nn.Linear(self.hidden_dim + 2 * self.edge_dim + 5, self.graph_dim),
            nn.SiLU(),
            nn.Linear(self.graph_dim, self.graph_dim),
            nn.SiLU(),
        )

        self.clean_edge_head = (
            nn.Sequential(
                nn.Linear(self.edge_dim, self.edge_dim), nn.SiLU(), nn.Linear(self.edge_dim, 2)
            ) if self.predict_edge_state else None
        )

        # [normalized current lambda_i, normalized source lambda_i,
        #  normalized rank i/(n-1), diffusion progress, normalized graph size,
        #  valid-token flag].  The source endpoint is explicit because training
        #  samples continuous bridge states rather than intermediate graphs.
        self.spectral_token_in = nn.Sequential(
            nn.Linear(6, self.spectral_dim),
            nn.SiLU(),
            nn.Linear(self.spectral_dim, self.spectral_dim),
        )
        self.graph_to_spectral = nn.Linear(self.graph_dim, self.spectral_dim)
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=self.spectral_dim,
            nhead=self.spectral_heads,
            dim_feedforward=self.spectral_ff_dim,
            dropout=self.dropout_p,
            activation="gelu",
            batch_first=True,
            norm_first=True,
        )
        self.spectral_transformer = nn.TransformerEncoder(
            encoder_layer,
            num_layers=self.spectral_layers,
            enable_nested_tensor=False,
        )
        self.spectral_norm = nn.LayerNorm(self.spectral_dim)
        self.gap_head = nn.Sequential(
            nn.Linear(self.spectral_dim, self.spectral_dim),
            nn.SiLU(),
            nn.Linear(self.spectral_dim, 1),
        )
        # Minimal structural-summary auxiliary head. It pools the same spectral
        # Transformer tokens used for x0 spectrum prediction, so when graph
        # context is disabled it cannot inspect adjacency/GNN features.
        clustering_hidden = max(self.spectral_dim // 2, 16)
        self.clustering_coefficient_head = (
            nn.Sequential(
                nn.Linear(self.spectral_dim, clustering_hidden),
                nn.SiLU(),
                nn.Linear(clustering_hidden, 1),
            )
            if self.predict_clustering_coefficient
            else None
        )

        self.clustering_histogram_head = (
            nn.Sequential(
                nn.Linear(self.spectral_dim, clustering_hidden),
                nn.SiLU(),
                nn.Linear(clustering_hidden, self.clustering_histogram_bins),
            )
            if self.predict_clustering_histogram else None
        )
        self.orbit_summary_head = (
            nn.Sequential(
                nn.Linear(self.spectral_dim, clustering_hidden),
                nn.SiLU(),
                nn.Linear(clustering_hidden, self.orbit_summary_width),
            )
            if self.predict_orbit_summary else None
        )

        self.cycle_graphlet_histogram_head = (
            nn.Sequential(
                nn.Linear(self.spectral_dim, clustering_hidden),
                nn.SiLU(),
                nn.Linear(clustering_hidden, 2),
            ) if self.predict_cycle_graphlet_histogram else None
        )

        self.induced_graphlet_histogram_head = (
            nn.Sequential(nn.Linear(self.spectral_dim, clustering_hidden), nn.SiLU(),
                          nn.Linear(clustering_hidden, self.induced_graphlet_spec.width))
            if self.predict_induced_graphlet_histogram else None
        )

    @staticmethod
    def _masked_pair_pool(
        values: torch.Tensor,
        mask: torch.Tensor,
    ) -> torch.Tensor:
        weights = mask.unsqueeze(-1).to(values.dtype)
        return (values * weights).sum(dim=(1, 2)) / weights.sum(
            dim=(1, 2)
        ).clamp_min(1.0)

    def _graph_context(self, batch: TopologySpectralBatch) -> torch.Tensor:
        adjacency = batch.adjacency.bool()
        node_mask = batch.node_mask.bool()
        pair_mask = batch.pair_mask.bool()
        if self.predict_edge_state:
            if batch.current_edge_logits is None or batch.source_edge_logits is None:
                raise ValueError("Generic edge diffusion is enabled but the batch has no edge bridge state.")
            current_edge_prob = torch.softmax(batch.current_edge_logits, dim=-1)[..., 1]
            source_edge_prob = torch.softmax(batch.source_edge_logits, dim=-1)[..., 1]
            message_adjacency = current_edge_prob * pair_mask.to(current_edge_prob.dtype)
        else:
            current_edge_prob = source_edge_prob = None
            message_adjacency = adjacency.to(batch.degrees.dtype)
        batch_size, node_count = node_mask.shape
        size_feature = batch.graph_size / (batch.graph_size + 1.0).clamp_min(1.0)

        node_features = torch.stack(
            [
                batch.degrees,
                size_feature.view(-1, 1).expand(batch_size, node_count),
                batch.time.view(-1, 1).expand(batch_size, node_count),
                node_mask.to(batch.degrees.dtype),
            ],
            dim=-1,
        )
        node_hidden = self.node_in(node_features)
        node_hidden = node_hidden * node_mask.unsqueeze(-1).to(node_hidden.dtype)

        degree_i = batch.degrees.unsqueeze(2).expand(
            batch_size, node_count, node_count
        )
        degree_j = batch.degrees.unsqueeze(1).expand(
            batch_size, node_count, node_count
        )
        pair_feature_values = [
            adjacency.to(batch.degrees.dtype),
            pair_mask.to(batch.degrees.dtype),
            batch.time.view(-1, 1, 1).expand(batch_size, node_count, node_count),
            0.5 * (degree_i + degree_j),
            torch.abs(degree_i - degree_j),
            degree_i * degree_j,
            size_feature.view(-1, 1, 1).expand(batch_size, node_count, node_count),
        ]
        if self.predict_edge_state:
            pair_feature_values.extend([current_edge_prob, source_edge_prob])
        edge_features = torch.stack(pair_feature_values, dim=-1)
        edge_hidden = self.edge_in(edge_features)
        edge_hidden = 0.5 * (edge_hidden + edge_hidden.transpose(1, 2))
        edge_hidden = edge_hidden * pair_mask.unsqueeze(-1).to(edge_hidden.dtype)

        for layer in self.layers:
            node_hidden, edge_hidden = layer(
                node_hidden,
                edge_hidden,
                message_adjacency,
                node_mask,
            )
            node_hidden = self.dropout(node_hidden)
            edge_hidden = self.dropout(edge_hidden)

        node_weights = node_mask.unsqueeze(-1).to(node_hidden.dtype)
        node_pool = (node_hidden * node_weights).sum(dim=1) / node_weights.sum(
            dim=1
        ).clamp_min(1.0)
        upper = torch.triu(
            torch.ones(
                (node_count, node_count),
                dtype=torch.bool,
                device=node_mask.device,
            ),
            diagonal=1,
        ).view(1, node_count, node_count)
        upper_pairs = pair_mask & upper
        present_pool = self._masked_pair_pool(
            edge_hidden,
            upper_pairs & adjacency,
        )
        absent_pool = self._masked_pair_pool(
            edge_hidden,
            upper_pairs & ~adjacency,
        )

        degree_weights = node_mask.to(batch.degrees.dtype)
        degree_count = degree_weights.sum(dim=1).clamp_min(1.0)
        degree_mean = (batch.degrees * degree_weights).sum(dim=1) / degree_count
        degree_variance = (
            (batch.degrees - degree_mean.unsqueeze(1)).square() * degree_weights
        ).sum(dim=1) / degree_count
        degree_max = batch.degrees.masked_fill(~node_mask, 0.0).max(dim=1).values
        graph_hidden = self.graph_encoder(
            torch.cat(
                [
                    node_pool,
                    present_pool,
                    absent_pool,
                    degree_mean.unsqueeze(1),
                    torch.sqrt(degree_variance.clamp_min(0.0)).unsqueeze(1),
                    degree_max.unsqueeze(1),
                    batch.time.unsqueeze(1),
                    size_feature.unsqueeze(1),
                ],
                dim=-1,
            )
        )
        return graph_hidden, edge_hidden

    def _spectrum_scale(self, batch: TopologySpectralBatch) -> torch.Tensor:
        # adjacency is symmetric, hence its total sum is exactly 2m.
        trace = batch.adjacency.to(batch.current_spectrum.dtype).sum(dim=(1, 2))
        if self.input_normalization in {"none", "raw"}:
            return torch.ones_like(trace)
        if self.input_normalization in {"trace", "degree_sum"}:
            return trace.clamp_min(1.0)
        return (trace / batch.graph_size.clamp_min(1.0)).clamp_min(1.0e-8)

    def _constrained_spectrum(
        self,
        raw_gap_scores: torch.Tensor,
        batch: TopologySpectralBatch,
    ) -> torch.Tensor:
        """Convert parallel gap scores into a sorted trace-preserving spectrum."""

        mask = batch.spectrum_mask.bool()
        batch_size, width = mask.shape
        token_index = torch.arange(width, device=mask.device).view(1, -1)
        # lambda_1 is fixed to zero, so only tokens 1..n-1 carry gaps.
        gap_mask = mask & (token_index > 0)
        positive_gap = F.softplus(raw_gap_scores) + float(self.min_gap)
        positive_gap = positive_gap * gap_mask.to(positive_gap.dtype)

        n = batch.graph_size.to(raw_gap_scores.dtype).view(-1, 1)
        # Gap at zero-based token j contributes to lambda_{j+1},...,lambda_n:
        # multiplicity n-j.
        multiplicity = (n - token_index.to(raw_gap_scores.dtype)).clamp_min(0.0)
        denominator = (positive_gap * multiplicity).sum(dim=1)
        trace = batch.adjacency.to(raw_gap_scores.dtype).sum(dim=(1, 2))
        scale = torch.where(
            denominator > 0.0,
            trace / denominator.clamp_min(1.0e-12),
            torch.zeros_like(denominator),
        )
        gaps = positive_gap * scale.unsqueeze(1)
        spectrum = torch.cumsum(gaps, dim=1)
        spectrum = spectrum * mask.to(spectrum.dtype)
        return spectrum

    def _spectral_outputs_from_graph_hidden(
        self,
        batch: TopologySpectralBatch,
        graph_hidden: torch.Tensor | None,
        degree_context: torch.Tensor | None = None,
    ) -> dict[str, torch.Tensor]:
        mask = batch.spectrum_mask.bool()
        batch_size, width = mask.shape
        scale = self._spectrum_scale(batch)
        normalized_lambda = batch.current_spectrum / scale.unsqueeze(1)
        normalized_source_lambda = batch.source_spectrum / scale.unsqueeze(1)

        indices = torch.arange(width, device=mask.device, dtype=normalized_lambda.dtype)
        denom = (batch.graph_size - 1.0).clamp_min(1.0).unsqueeze(1)
        rank = indices.view(1, -1).expand(batch_size, -1) / denom
        size_feature = batch.graph_size / (batch.graph_size + 1.0).clamp_min(1.0)
        token_features = torch.stack(
            [
                normalized_lambda,
                normalized_source_lambda,
                rank,
                batch.time.unsqueeze(1).expand(batch_size, width),
                size_feature.unsqueeze(1).expand(batch_size, width),
                mask.to(normalized_lambda.dtype),
            ],
            dim=-1,
        )
        tokens = self.spectral_token_in(token_features)
        if degree_context is not None:
            tokens = tokens + degree_context.unsqueeze(1)
        if graph_hidden is not None:
            tokens = tokens + self.graph_to_spectral(graph_hidden).unsqueeze(1)
        tokens = tokens * mask.unsqueeze(-1).to(tokens.dtype)
        encoded = self.spectral_transformer(
            tokens,
            src_key_padding_mask=~mask,
        )
        encoded = self.spectral_norm(encoded)
        raw_gap_scores = self.gap_head(encoded).squeeze(-1)
        clean_spectrum = self._constrained_spectrum(raw_gap_scores, batch)
        result = {
            "clean_spectrum": clean_spectrum,
            "raw_gap_scores": raw_gap_scores,
            "spectral_mask": mask,
        }
        if (
            self.clustering_coefficient_head is not None
            or self.clustering_histogram_head is not None
            or self.orbit_summary_head is not None
            or self.cycle_graphlet_histogram_head is not None
            or self.induced_graphlet_histogram_head is not None
        ):
            weights = mask.unsqueeze(-1).to(encoded.dtype)
            pooled = (encoded * weights).sum(dim=1) / weights.sum(dim=1).clamp_min(1.0)
        if self.clustering_histogram_head is not None:
            logits = self.clustering_histogram_head(pooled)
            result["clean_clustering_histogram_logits"] = logits
            result["clean_clustering_histogram"] = torch.softmax(logits, dim=-1)
        if self.induced_graphlet_histogram_head is not None:
            logits = self.induced_graphlet_histogram_head(pooled)
            result["clean_induced_graphlet_histogram_logits"] = logits
            result["clean_induced_graphlet_histogram"] = mask_prediction(
                induced_block_softmax(logits, self.induced_graphlet_spec), batch.graph_size, self.induced_graphlet_spec)
        if self.cycle_graphlet_histogram_head is not None:
            cycle_logits = self.cycle_graphlet_histogram_head(pooled)
            cycle_histogram = torch.softmax(cycle_logits, dim=-1)
            cycle_valid = batch.graph_size >= self.cycle_graphlet_k
            empty_histogram = torch.zeros_like(cycle_histogram)
            empty_histogram[:, 1] = 1.0
            result["clean_cycle_graphlet_histogram_logits"] = cycle_logits
            result["clean_cycle_graphlet_histogram"] = torch.where(
                cycle_valid.unsqueeze(-1), cycle_histogram, empty_histogram
            )
        if self.orbit_summary_head is not None:
            # Predict log1p(mean per-node orbit counts). Softplus keeps the
            # latent log-count target non-negative; expm1 maps it back to the
            # evaluator-compatible raw 15-D orbit descriptor.
            orbit_log_mean = F.softplus(self.orbit_summary_head(pooled))
            result["clean_orbit_log_mean"] = orbit_log_mean
            result["clean_orbit_summary"] = torch.expm1(orbit_log_mean).clamp_min(0.0)
        if self.clustering_coefficient_head is not None:
            result["clean_clustering_coefficient"] = torch.sigmoid(
                self.clustering_coefficient_head(pooled).squeeze(-1)
            )
        return result

    def forward(self, batch: TopologySpectralBatch) -> dict[str, torch.Tensor]:
        # Debug-friendly spectral-only mode deliberately removes adjacency/GNN
        # context from the denoiser.  The network then receives only the noisy
        # bridge spectrum, the fixed HH/source spectrum, normalized rank,
        # diffusion progress, graph size, and the padding mask.  The adjacency
        # is still carried by the batch for invariant trace normalization, but
        # its topology is not encoded by the neural predictor.
        edge_hidden = None
        if self.use_graph_context:
            graph_hidden, edge_hidden = self._graph_context(batch)
        else:
            graph_hidden = None
            if self.predict_edge_state:
                raise ValueError("predict_edge_state requires use_graph_context=true.")
        outputs = self._spectral_outputs_from_graph_hidden(batch, graph_hidden)
        if self.clean_edge_head is not None:
            logits = self.clean_edge_head(edge_hidden)
            logits = 0.5 * (logits + logits.transpose(1, 2))
            logits = logits - logits.mean(dim=-1, keepdim=True)
            logits = logits * batch.pair_mask.unsqueeze(-1).to(logits.dtype)
            outputs["clean_edge_logits"] = logits
            outputs["clean_edge_probabilities"] = torch.softmax(logits, dim=-1)
        return outputs

    def _spectral_loss_from_outputs(
        self,
        batch: TopologySpectralBatch,
        outputs: dict[str, torch.Tensor],
        *,
        loss_weights: dict[str, float] | None = None,
    ) -> tuple[torch.Tensor, dict[str, float]]:
        weights = dict(loss_weights or {})
        predicted = outputs["clean_spectrum"]
        target = batch.clean_spectrum_target
        mask = batch.spectrum_mask.bool()
        scale = self._spectrum_scale(batch).unsqueeze(1)
        valid_weight = mask.to(predicted.dtype)
        count = valid_weight.sum().clamp_min(1.0)
        normalized_delta = (predicted - target) / scale

        spectrum_loss = (
            F.smooth_l1_loss(
                predicted / scale,
                target / scale,
                reduction="none",
            )
            * valid_weight
        ).sum() / count

        predicted_m2 = (predicted.square() * valid_weight).sum(dim=1)
        target_m2 = (target.square() * valid_weight).sum(dim=1)
        m2_scale = target_m2.abs().clamp_min(1.0)
        moment2_loss = F.smooth_l1_loss(
            predicted_m2 / m2_scale,
            target_m2 / m2_scale,
        )

        # Optional extra emphasis on low-frequency eigenvalues after lambda_1.
        low_k = int(weights.get("low_frequency_k", 0))
        low_frequency_loss = predicted.sum() * 0.0
        if low_k > 0:
            token_index = torch.arange(mask.shape[1], device=mask.device).view(1, -1)
            low_mask = mask & (token_index > 0) & (token_index <= low_k)
            if torch.any(low_mask):
                low_weight = low_mask.to(predicted.dtype)
                low_frequency_loss = (
                    F.smooth_l1_loss(
                        predicted / scale,
                        target / scale,
                        reduction="none",
                    )
                    * low_weight
                ).sum() / low_weight.sum().clamp_min(1.0)

        total = (
            float(weights.get("spectrum", 1.0)) * spectrum_loss
            + float(weights.get("moment2", 0.1)) * moment2_loss
            + float(weights.get("low_frequency", 0.0)) * low_frequency_loss
        )

        edge_metrics: dict[str, float] = {}
        if self.predict_edge_state:
            if batch.clean_edge_labels_target is None or batch.clean_edge_logits_target is None:
                raise ValueError("Edge diffusion head enabled but batch has no clean edge target.")
            edge_logits = outputs["clean_edge_logits"]
            upper = torch.triu(torch.ones_like(batch.pair_mask, dtype=torch.bool), diagonal=1)
            pm = batch.pair_mask.bool() & upper
            ce_all = F.cross_entropy(edge_logits.permute(0,3,1,2), batch.clean_edge_labels_target.long(), reduction="none")
            denom = pm.to(edge_logits.dtype).sum().clamp_min(1.0)
            edge_ce = (ce_all * pm.to(ce_all.dtype)).sum() / denom
            edge_logit = (((edge_logits - batch.clean_edge_logits_target.to(edge_logits.dtype)).square().mean(-1)) * pm.to(edge_logits.dtype)).sum() / denom
            total = total + float(weights.get("edge_ce", 1.0)) * edge_ce + float(weights.get("edge_logit", 0.1)) * edge_logit
            with torch.no_grad():
                edge_acc = (((edge_logits.argmax(-1) == batch.clean_edge_labels_target) & pm).to(edge_logits.dtype).sum() / denom)
                edge_metrics = {"edge_ce_loss": float(edge_ce.detach().cpu()), "edge_logit_loss": float(edge_logit.detach().cpu()), "edge_accuracy": float(edge_acc.detach().cpu())}

        clustering_loss = predicted.sum() * 0.0
        clustering_mae = predicted.sum() * 0.0
        clustering_rmse = predicted.sum() * 0.0
        if self.predict_clustering_coefficient:
            if batch.clean_clustering_coefficient_target is None:
                raise ValueError(
                    "Clustering-coefficient prediction is enabled but the spectral "
                    "batch has no clean clustering target."
                )
            predicted_clustering = outputs["clean_clustering_coefficient"]
            target_clustering = batch.clean_clustering_coefficient_target.to(
                predicted_clustering.dtype
            )
            clustering_loss = F.smooth_l1_loss(
                predicted_clustering, target_clustering
            )
            total = total + float(
                weights.get("clustering_coefficient", 1.0)
            ) * clustering_loss
            with torch.no_grad():
                clustering_delta = predicted_clustering - target_clustering
                clustering_mae = torch.mean(torch.abs(clustering_delta))
                clustering_rmse = torch.sqrt(torch.mean(clustering_delta.square()))

        histogram_metrics: dict[str, float] = {}
        if self.predict_clustering_histogram:
            histogram_target = batch.clean_clustering_histogram_target
            histogram_prediction = outputs["clean_clustering_histogram"]
            if histogram_target is None:
                raise ValueError("Clustering-histogram prediction is enabled but the batch has no histogram target.")
            histogram_target = histogram_target.to(histogram_prediction.dtype)
            if histogram_target.shape != histogram_prediction.shape:
                raise ValueError("Clustering histogram target width does not match the checkpoint bin count.")
            # CDF loss respects the ordering of coefficient bins. The final
            # CDF entry is constant 1 and is omitted; spacing is 1 / bins.
            cdf_delta = torch.cumsum(histogram_prediction - histogram_target, dim=-1)[..., :-1]
            histogram_loss = cdf_delta.square().sum(dim=-1).mean() / self.clustering_histogram_bins
            histogram_ce = -(
                histogram_target
                * F.log_softmax(outputs["clean_clustering_histogram_logits"], dim=-1)
            ).sum(dim=-1).mean()
            total = total + float(weights.get("clustering_histogram", 1.0)) * histogram_loss
            total = total + float(weights.get("clustering_histogram_ce", 0.0)) * histogram_ce
            with torch.no_grad():
                histogram_w1 = cdf_delta.abs().sum(dim=-1).mean() / self.clustering_histogram_bins
                histogram_tv = 0.5 * (histogram_prediction - histogram_target).abs().sum(dim=-1).mean()
                histogram_metrics = {
                    "clustering_histogram_loss": float(histogram_loss.detach().cpu()),
                    "clustering_histogram_ce": float(histogram_ce.detach().cpu()),
                    "clustering_histogram_w1": float(histogram_w1.detach().cpu()),
                    "clustering_histogram_tv": float(histogram_tv.detach().cpu()),
                }

        orbit_metrics: dict[str, float] = {}
        if self.predict_orbit_summary:
            orbit_target = batch.clean_orbit_summary_target
            if orbit_target is None:
                raise ValueError("Orbit-summary prediction is enabled but the batch has no orbit target.")
            orbit_prediction = outputs["clean_orbit_summary"]
            orbit_log_prediction = outputs["clean_orbit_log_mean"]
            orbit_target = orbit_target.to(orbit_prediction.dtype)
            if orbit_target.shape != orbit_prediction.shape:
                raise ValueError("Orbit summary target width does not match the checkpoint orbit width.")
            orbit_log_target = torch.log1p(orbit_target.clamp_min(0.0))
            orbit_loss = F.smooth_l1_loss(orbit_log_prediction, orbit_log_target)
            total = total + float(weights.get("orbit_summary", 1.0)) * orbit_loss
            with torch.no_grad():
                log_delta = orbit_log_prediction - orbit_log_target
                orbit_log_rmse = torch.sqrt(torch.mean(log_delta.square()))
                orbit_log_mae = torch.mean(torch.abs(log_delta))
                raw_scale = torch.sqrt(torch.mean(orbit_target.square(), dim=-1)).clamp_min(1.0)
                raw_nrmse = torch.sqrt(torch.mean((orbit_prediction - orbit_target).square(), dim=-1)) / raw_scale
                orbit_metrics = {
                    "orbit_summary_loss": float(orbit_loss.detach().cpu()),
                    "orbit_summary_log_rmse": float(orbit_log_rmse.detach().cpu()),
                    "orbit_summary_log_mae": float(orbit_log_mae.detach().cpu()),
                    "orbit_summary_raw_nrmse": float(raw_nrmse.mean().detach().cpu()),
                }

        induced_metrics: dict[str, float] = {}
        if self.predict_induced_graphlet_histogram:
            if batch.clean_induced_graphlet_histogram_target is None:
                raise ValueError("Induced graphlet head enabled but batch has no target.")
            loss_brier, loss_ce, measured = induced_prediction_loss(
                outputs["clean_induced_graphlet_histogram_logits"],
                batch.clean_induced_graphlet_histogram_target, batch.graph_size,
                self.induced_graphlet_spec)
            total = total + float(weights.get("induced_graphlet_histogram", 1.0)) * loss_brier
            total = total + float(weights.get("induced_graphlet_histogram_ce", 0.0)) * loss_ce
            induced_metrics = {key: float(value.detach().cpu()) for key, value in measured.items()}
        cycle_metrics: dict[str, float] = {}
        if self.predict_cycle_graphlet_histogram:
            cycle_prediction = outputs["clean_cycle_graphlet_histogram"]
            cycle_target = batch.clean_cycle_graphlet_histogram_target
            if cycle_target is None:
                raise ValueError("Cycle graphlet prediction is enabled but the batch has no clean cycle target.")
            cycle_target = cycle_target.to(cycle_prediction.dtype)
            if cycle_target.shape != cycle_prediction.shape:
                raise ValueError("Cycle graphlet targets must have shape [batch_size, 2].")
            valid = (batch.graph_size >= self.cycle_graphlet_k).to(cycle_prediction.dtype)
            denominator = valid.sum().clamp_min(1.0)
            cycle_delta = cycle_prediction[:, 0] - cycle_target[:, 0]
            # Two-bin MSE equals squared induced-C_k-density error. Graphs
            # with fewer than k nodes are excluded rather than taught fictitious trials.
            cycle_loss = (cycle_delta.square() * valid).sum() / denominator
            cycle_ce_per_graph = -(cycle_target * F.log_softmax(
                outputs["clean_cycle_graphlet_histogram_logits"], dim=-1
            )).sum(dim=-1)
            cycle_ce = (cycle_ce_per_graph * valid).sum() / denominator
            total = total + float(weights.get("cycle_graphlet_histogram", 1.0)) * cycle_loss
            total = total + float(weights.get("cycle_graphlet_histogram_ce", 0.0)) * cycle_ce
            with torch.no_grad():
                n = batch.graph_size.to(cycle_prediction.dtype)
                subsets = torch.ones_like(n)
                for offset in range(self.cycle_graphlet_k):
                    subsets = subsets * (n - float(offset)).clamp_min(0.0)
                for divisor in range(2, self.cycle_graphlet_k + 1):
                    subsets = subsets / float(divisor)
                cycle_metrics = {
                    "cycle_graphlet_histogram_loss": float(cycle_loss.detach().cpu()),
                    "cycle_graphlet_histogram_ce": float(cycle_ce.detach().cpu()),
                    "cycle_graphlet_histogram_tv": float(((cycle_delta.abs() * valid).sum() / denominator).cpu()),
                    "cycle_graphlet_count_mae": float(((cycle_delta.abs() * subsets * valid).sum() / denominator).cpu()),
                    "cycle_graphlet_valid_fraction": float(valid.mean().cpu()),
                }

        with torch.no_grad():
            abs_delta = torch.abs(predicted - target) * valid_weight
            spectral_mae = abs_delta.sum() / count
            spectral_rmse = torch.sqrt(
                (normalized_delta.square() * valid_weight).sum() / count
            )
            normalized_mae = (
                torch.abs(normalized_delta) * valid_weight
            ).sum() / count
            trace_pred = (predicted * valid_weight).sum(dim=1)
            trace_target = (target * valid_weight).sum(dim=1)
            trace_error = torch.mean(torch.abs(trace_pred - trace_target))
            moment2_relative_error = torch.mean(
                torch.abs(predicted_m2 - target_m2) / m2_scale
            )
            if predicted.shape[1] > 1:
                pair_mask = mask[:, 1:] & mask[:, :-1]
                monotonic_violations = (
                    ((predicted[:, 1:] + 1.0e-7) < predicted[:, :-1]) & pair_mask
                ).to(predicted.dtype).sum()
            else:
                monotonic_violations = predicted.sum() * 0.0
            lambda1_error = torch.mean(torch.abs(predicted[:, 0]))

        metrics = {
            "loss": float(total.detach().cpu()),
            "spectrum_loss": float(spectrum_loss.detach().cpu()),
            "spectral_loss": float(spectrum_loss.detach().cpu()),
            "moment2_loss": float(moment2_loss.detach().cpu()),
            "low_frequency_loss": float(low_frequency_loss.detach().cpu()),
            "spectral_mae": float(spectral_mae.detach().cpu()),
            "spectral_normalized_mae": float(normalized_mae.detach().cpu()),
            "spectral_normalized_rmse": float(spectral_rmse.detach().cpu()),
            "spectral_trace_mae": float(trace_error.detach().cpu()),
            "spectral_moment2_relative_error": float(
                moment2_relative_error.detach().cpu()
            ),
            "spectral_lambda1_mae": float(lambda1_error.detach().cpu()),
            "spectral_monotonic_violations": float(
                monotonic_violations.detach().cpu()
            ),
        }
        if self.predict_clustering_coefficient:
            metrics.update(
                {
                    "clustering_coefficient_loss": float(
                        clustering_loss.detach().cpu()
                    ),
                    "clustering_coefficient_mae": float(
                        clustering_mae.detach().cpu()
                    ),
                    "clustering_coefficient_rmse": float(
                        clustering_rmse.detach().cpu()
                    ),
                }
            )
        metrics.update(histogram_metrics)
        metrics.update(orbit_metrics)
        metrics.update(cycle_metrics)
        metrics.update(induced_metrics)
        metrics.update(edge_metrics)
        return total, metrics


    def loss(
        self,
        batch: TopologySpectralBatch,
        *,
        loss_weights: dict[str, float] | None = None,
    ) -> tuple[torch.Tensor, dict[str, float]]:
        outputs = self.forward(batch)
        return self._spectral_loss_from_outputs(
            batch,
            outputs,
            loss_weights=loss_weights,
        )

    def model_config(self) -> dict[str, Any]:
        return {
            "hidden_dim": self.hidden_dim,
            "edge_dim": self.edge_dim,
            "graph_dim": self.graph_dim,
            "num_layers": self.num_layers,
            "spectral_dim": self.spectral_dim,
            "spectral_layers": self.spectral_layers,
            "spectral_heads": self.spectral_heads,
            "spectral_ff_dim": self.spectral_ff_dim,
            "dropout": self.dropout_p,
            "min_gap": self.min_gap,
            "input_normalization": self.input_normalization,
            "use_graph_context": self.use_graph_context,
            "predict_clustering_coefficient": self.predict_clustering_coefficient,
            "predict_clustering_histogram": self.predict_clustering_histogram,
            "clustering_histogram_bins": self.clustering_histogram_bins,
            "predict_orbit_summary": self.predict_orbit_summary,
            "orbit_summary_width": self.orbit_summary_width,
            "predict_cycle_graphlet_histogram": self.predict_cycle_graphlet_histogram,
            "cycle_graphlet_k": self.cycle_graphlet_k,
            "predict_induced_graphlet_histogram": self.predict_induced_graphlet_histogram,
            "induced_graphlet_k": self.induced_graphlet_k,
            "induced_graphlet_k_min": self.induced_graphlet_k_min,
            "induced_graphlet_k_max": self.induced_graphlet_k_max,
            "induced_graphlet_scope": self.induced_graphlet_scope,
            "induced_graphlet_catalogue_fingerprint": self.induced_graphlet_spec.metadata()["fingerprint"],
            "predict_edge_state": self.predict_edge_state,
            "edge_smoothing": self.edge_smoothing,
        }



class TopologySpectralGraphletTransformerPredictor(TopologySpectralTransformerPredictor):
    """Joint global-spectrum and local-graphlet x0 predictor.

    The graph encoder is shared.  The spectral branch is the variable-length
    Spectral Transformer.  For each graphlet order k, a residual MLP consumes
    the shared graph context together with the current CLR/logit graphlet state
    and predicts the clean CLR state in one shot.  A blockwise softmax maps the
    predicted logits back to a valid graphlet probability simplex.
    """

    def __init__(
        self,
        *,
        graphlet_block_widths: Sequence[int],
        graphlet_dim: int = 256,
        graphlet_dropout: float = 0.05,
        graphlet_logit_epsilon: float = 1.0e-5,
        degree_summary_enabled: bool = False,
        degree_summary_dim: int = 256,
        degree_summary_layers: int = 2,
        degree_summary_dropout: float = 0.05,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.graphlet_block_widths = tuple(int(value) for value in graphlet_block_widths)
        if not self.graphlet_block_widths or any(value <= 1 for value in self.graphlet_block_widths):
            raise ValueError("graphlet_block_widths must contain simplex widths >= 2.")
        self.graphlet_dim = int(graphlet_dim)
        self.graphlet_dropout_p = float(graphlet_dropout)
        self.graphlet_logit_epsilon = float(graphlet_logit_epsilon)
        self.degree_summary_enabled = bool(degree_summary_enabled)
        self.degree_summary_dim = int(degree_summary_dim)
        self.degree_summary_layers = int(degree_summary_layers)
        self.degree_summary_dropout_p = float(degree_summary_dropout)
        if self.graphlet_dim <= 0:
            raise ValueError("graphlet_dim must be positive.")
        if self.graphlet_logit_epsilon <= 0.0:
            raise ValueError("graphlet_logit_epsilon must be positive.")
        self.graphlet_slices: tuple[tuple[int, int], ...] = self._make_slices(
            self.graphlet_block_widths
        )
        self.graphlet_heads = nn.ModuleList(
            [
                nn.Sequential(
                    nn.Linear(self.graph_dim + 2 * width, self.graphlet_dim),
                    nn.SiLU(),
                    nn.Dropout(self.graphlet_dropout_p),
                    nn.Linear(self.graphlet_dim, self.graphlet_dim),
                    nn.SiLU(),
                    nn.Linear(self.graphlet_dim, width),
                )
                for width in self.graphlet_block_widths
            ]
        )
        if self.degree_summary_enabled:
            if self.degree_summary_dim <= 0 or self.degree_summary_layers <= 0:
                raise ValueError("degree summary dimensions/layers must be positive.")
            self.degree_token_in = nn.Sequential(
                nn.Linear(4, self.degree_summary_dim),
                nn.SiLU(),
                nn.Linear(self.degree_summary_dim, self.degree_summary_dim),
            )
            self.degree_token_layers = nn.ModuleList(
                [
                    nn.Sequential(
                        nn.LayerNorm(self.degree_summary_dim),
                        nn.Linear(self.degree_summary_dim, self.degree_summary_dim),
                        nn.SiLU(),
                        nn.Dropout(self.degree_summary_dropout_p),
                        nn.Linear(self.degree_summary_dim, self.degree_summary_dim),
                    )
                    for _ in range(self.degree_summary_layers)
                ]
            )
            self.degree_graph_encoder = nn.Sequential(
                nn.Linear(2 * self.degree_summary_dim + 4, self.degree_summary_dim),
                nn.SiLU(),
                nn.Linear(self.degree_summary_dim, self.degree_summary_dim),
                nn.SiLU(),
            )
            self.degree_spectral_token_in = nn.Sequential(
                nn.Linear(3, self.degree_summary_dim),
                nn.SiLU(),
                nn.Linear(self.degree_summary_dim, self.degree_summary_dim),
            )
            self.degree_spectral_head = nn.Sequential(
                nn.LayerNorm(self.degree_summary_dim),
                nn.Linear(self.degree_summary_dim, self.degree_summary_dim),
                nn.SiLU(),
                nn.Linear(self.degree_summary_dim, 1),
            )
            self.degree_graphlet_heads = nn.ModuleList(
                [
                    nn.Sequential(
                        nn.Linear(self.degree_summary_dim, self.graphlet_dim),
                        nn.SiLU(),
                        nn.Dropout(self.degree_summary_dropout_p),
                        nn.Linear(self.graphlet_dim, width),
                    )
                    for width in self.graphlet_block_widths
                ]
            )

    @staticmethod
    def _make_slices(widths: Sequence[int]) -> tuple[tuple[int, int], ...]:
        result: list[tuple[int, int]] = []
        start = 0
        for width in widths:
            stop = start + int(width)
            result.append((start, stop))
            start = stop
        return tuple(result)

    @property
    def graphlet_width(self) -> int:
        return sum(self.graphlet_block_widths)

    def _graphlet_outputs_from_graph_hidden(
        self,
        batch: TopologySpectralBatch,
        graph_hidden: torch.Tensor,
    ) -> dict[str, torch.Tensor]:
        if (
            batch.current_graphlet_logits is None
            or batch.source_graphlet_logits is None
            or batch.graphlet_coordinate_mask is None
        ):
            raise ValueError(
                "Spectral+graphlet prediction requires current graphlet CLR/logit inputs."
            )
        current = batch.current_graphlet_logits
        source = batch.source_graphlet_logits
        mask = batch.graphlet_coordinate_mask.bool()
        if current.shape[1] != self.graphlet_width:
            raise ValueError(
                f"Expected {self.graphlet_width} graphlet logits, received {current.shape[1]}."
            )
        clean_blocks: list[torch.Tensor] = []
        probability_blocks: list[torch.Tensor] = []
        residual_blocks: list[torch.Tensor] = []
        for (start, stop), head in zip(self.graphlet_slices, self.graphlet_heads):
            current_block = current[:, start:stop]
            source_block = source[:, start:stop]
            block_mask = mask[:, start:stop]
            block_valid = block_mask.any(dim=1, keepdim=True)
            residual = head(torch.cat([graph_hidden, current_block, source_block], dim=-1))
            clean = current_block + residual
            # CLR coordinates have an arbitrary additive gauge.  Centering makes
            # the network target identifiable and matches the training transform.
            clean = clean - clean.mean(dim=-1, keepdim=True)
            clean = clean * block_valid.to(clean.dtype)
            probability = torch.softmax(clean, dim=-1) * block_valid.to(clean.dtype)
            clean_blocks.append(clean)
            probability_blocks.append(probability)
            residual_blocks.append(residual * block_valid.to(residual.dtype))
        return {
            "clean_graphlet_logits": torch.cat(clean_blocks, dim=-1),
            "clean_graphlet_probabilities": torch.cat(probability_blocks, dim=-1),
            "raw_graphlet_logit_residual": torch.cat(residual_blocks, dim=-1),
            "graphlet_mask": mask,
        }

    def _degree_summary_outputs(
        self,
        batch: TopologySpectralBatch,
    ) -> dict[str, torch.Tensor]:
        """Predict clean spectrum/graphlets from the degree multiset alone.

        Degrees are sorted canonically before encoding, so this branch is
        invariant to node relabeling.  It deliberately does not read adjacency,
        current spectrum, graphlets, or diffusion time.  The resulting summary
        is used to enrich a sampled HH realization before the main refiner.
        """

        if not self.degree_summary_enabled:
            return {}
        mask = batch.node_mask.bool()
        batch_size, width = mask.shape
        # Padding gets -1 before sorting so every real normalized degree stays
        # in the first n positions even when isolated nodes are possible.
        padded = batch.degrees.masked_fill(~mask, -1.0)
        sorted_degree, _ = torch.sort(padded, dim=1, descending=True)
        sorted_mask = (
            torch.arange(width, device=mask.device).view(1, -1)
            < batch.graph_size.long().view(-1, 1)
        )
        sorted_degree = sorted_degree.masked_fill(~sorted_mask, 0.0)
        denom = (batch.graph_size - 1.0).clamp_min(1.0).unsqueeze(1)
        rank = torch.arange(
            width, device=mask.device, dtype=batch.degrees.dtype
        ).view(1, -1).expand(batch_size, -1) / denom
        size_feature = batch.graph_size / (batch.graph_size + 1.0).clamp_min(1.0)
        token_features = torch.stack(
            [
                sorted_degree,
                sorted_degree.square(),
                rank,
                size_feature.unsqueeze(1).expand(batch_size, width),
            ],
            dim=-1,
        )
        hidden = self.degree_token_in(token_features)
        weights = sorted_mask.unsqueeze(-1).to(hidden.dtype)
        hidden = hidden * weights
        for layer in self.degree_token_layers:
            hidden = (hidden + layer(hidden)) * weights
        count = weights.sum(dim=1).clamp_min(1.0)
        mean_pool = (hidden * weights).sum(dim=1) / count
        neg_inf = torch.finfo(hidden.dtype).min
        max_pool = hidden.masked_fill(~sorted_mask.unsqueeze(-1), neg_inf).max(dim=1).values
        max_pool = torch.where(torch.isfinite(max_pool), max_pool, torch.zeros_like(max_pool))

        degree_count = sorted_mask.to(batch.degrees.dtype).sum(dim=1).clamp_min(1.0)
        degree_mean = (sorted_degree * sorted_mask).sum(dim=1) / degree_count
        degree_var = (
            (sorted_degree - degree_mean.unsqueeze(1)).square()
            * sorted_mask.to(sorted_degree.dtype)
        ).sum(dim=1) / degree_count
        degree_max = sorted_degree.max(dim=1).values
        graph_hidden = self.degree_graph_encoder(
            torch.cat(
                [
                    mean_pool,
                    max_pool,
                    degree_mean.unsqueeze(1),
                    torch.sqrt(degree_var.clamp_min(0.0)).unsqueeze(1),
                    degree_max.unsqueeze(1),
                    size_feature.unsqueeze(1),
                ],
                dim=-1,
            )
        )

        spectrum_mask = batch.spectrum_mask.bool()
        spectral_rank = torch.arange(
            spectrum_mask.shape[1],
            device=mask.device,
            dtype=batch.degrees.dtype,
        ).view(1, -1).expand(batch_size, -1) / denom
        spectral_features = torch.stack(
            [
                spectral_rank,
                size_feature.unsqueeze(1).expand_as(spectral_rank),
                spectrum_mask.to(batch.degrees.dtype),
            ],
            dim=-1,
        )
        spectral_hidden = self.degree_spectral_token_in(spectral_features)
        spectral_hidden = spectral_hidden + graph_hidden.unsqueeze(1)
        raw_gap = self.degree_spectral_head(spectral_hidden).squeeze(-1)
        clean_spectrum = self._constrained_spectrum(raw_gap, batch)

        clean_blocks: list[torch.Tensor] = []
        probability_blocks: list[torch.Tensor] = []
        graphlet_mask = batch.graphlet_coordinate_mask
        if graphlet_mask is None:
            raise ValueError("Degree-conditioned graphlet summary requires a graphlet mask.")
        for (start, stop), head in zip(self.graphlet_slices, self.degree_graphlet_heads):
            valid = graphlet_mask[:, start:stop].any(dim=1, keepdim=True)
            block = head(graph_hidden)
            block = block - block.mean(dim=-1, keepdim=True)
            block = block * valid.to(block.dtype)
            probability = torch.softmax(block, dim=-1) * valid.to(block.dtype)
            clean_blocks.append(block)
            probability_blocks.append(probability)
        return {
            "degree_clean_spectrum": clean_spectrum,
            "degree_clean_graphlet_logits": torch.cat(clean_blocks, dim=-1),
            "degree_clean_graphlet_probabilities": torch.cat(probability_blocks, dim=-1),
        }

    def degree_summary(self, batch: TopologySpectralBatch) -> dict[str, torch.Tensor]:
        if not self.degree_summary_enabled:
            raise ValueError("This checkpoint has no degree-conditioned summary estimator.")
        return self._degree_summary_outputs(batch)

    def forward(self, batch: TopologySpectralBatch) -> dict[str, torch.Tensor]:
        graph_hidden, edge_hidden = self._graph_context(batch)
        outputs = self._spectral_outputs_from_graph_hidden(batch, graph_hidden)
        if self.clean_edge_head is not None:
            logits = self.clean_edge_head(edge_hidden)
            logits = 0.5 * (logits + logits.transpose(1, 2))
            logits = logits - logits.mean(dim=-1, keepdim=True)
            logits = logits * batch.pair_mask.unsqueeze(-1).to(logits.dtype)
            outputs["clean_edge_logits"] = logits
            outputs["clean_edge_probabilities"] = torch.softmax(logits, dim=-1)
        outputs.update(self._graphlet_outputs_from_graph_hidden(batch, graph_hidden))
        outputs.update(self._degree_summary_outputs(batch))
        return outputs

    def loss(
        self,
        batch: TopologySpectralBatch,
        *,
        loss_weights: dict[str, float] | None = None,
    ) -> tuple[torch.Tensor, dict[str, float]]:
        if (
            batch.clean_graphlet_logits_target is None
            or batch.clean_graphlet_probabilities_target is None
            or batch.graphlet_coordinate_mask is None
        ):
            raise ValueError("Spectral+graphlet loss requires clean graphlet targets.")
        weights = dict(loss_weights or {})
        outputs = self.forward(batch)
        spectral_total, metrics = self._spectral_loss_from_outputs(
            batch,
            outputs,
            loss_weights=weights,
        )
        predicted_logits = outputs["clean_graphlet_logits"]
        target_logits = batch.clean_graphlet_logits_target
        predicted_prob = outputs["clean_graphlet_probabilities"]
        target_prob = batch.clean_graphlet_probabilities_target
        mask = batch.graphlet_coordinate_mask.bool()
        mask_weight = mask.to(predicted_logits.dtype)
        coordinate_count = mask_weight.sum().clamp_min(1.0)

        graphlet_logit_loss = (
            F.smooth_l1_loss(predicted_logits, target_logits, reduction="none")
            * mask_weight
        ).sum() / coordinate_count

        probability_terms: list[torch.Tensor] = []
        block_mae_terms: list[torch.Tensor] = []
        for start, stop in self.graphlet_slices:
            valid = mask[:, start:stop].any(dim=1)
            if not torch.any(valid):
                continue
            pred = predicted_prob[valid, start:stop].clamp_min(1.0e-12)
            target = target_prob[valid, start:stop]
            target = target / target.sum(dim=-1, keepdim=True).clamp_min(1.0e-12)
            # KL(target || prediction) is zero at a perfect prediction, unlike
            # plain cross entropy whose entropy constant would otherwise make
            # this auxiliary term difficult to interpret in training logs.
            target_safe = target.clamp_min(1.0e-12)
            probability_terms.append(
                (target * (torch.log(target_safe) - torch.log(pred))).sum(dim=-1).mean()
            )
            block_mae_terms.append(torch.abs(pred - target).mean())
        graphlet_probability_loss = (
            torch.stack(probability_terms).mean()
            if probability_terms
            else predicted_logits.sum() * 0.0
        )
        probability_mae = (
            torch.stack(block_mae_terms).mean()
            if block_mae_terms
            else predicted_logits.sum() * 0.0
        )
        graphlet_total = (
            float(weights.get("graphlet_logit", 1.0)) * graphlet_logit_loss
            + float(weights.get("graphlet_probability", 0.25)) * graphlet_probability_loss
        )
        total = spectral_total + graphlet_total
        degree_summary_weight = float(weights.get("degree_summary", 0.0))
        degree_summary_total = predicted_logits.sum() * 0.0
        degree_metrics: dict[str, float] = {}
        if self.degree_summary_enabled and degree_summary_weight > 0.0:
            degree_spectral_outputs = {
                "clean_spectrum": outputs["degree_clean_spectrum"]
            }
            degree_spectral_total, raw_degree_metrics = self._spectral_loss_from_outputs(
                batch,
                degree_spectral_outputs,
                loss_weights=weights,
            )
            degree_logits = outputs["degree_clean_graphlet_logits"]
            degree_prob = outputs["degree_clean_graphlet_probabilities"]
            degree_logit_loss = (
                F.smooth_l1_loss(degree_logits, target_logits, reduction="none")
                * mask_weight
            ).sum() / coordinate_count
            degree_probability_terms: list[torch.Tensor] = []
            for start, stop in self.graphlet_slices:
                valid = mask[:, start:stop].any(dim=1)
                if not torch.any(valid):
                    continue
                pred = degree_prob[valid, start:stop].clamp_min(1.0e-12)
                target = target_prob[valid, start:stop]
                target = target / target.sum(dim=-1, keepdim=True).clamp_min(1.0e-12)
                target_safe = target.clamp_min(1.0e-12)
                degree_probability_terms.append(
                    (target * (torch.log(target_safe) - torch.log(pred))).sum(dim=-1).mean()
                )
            degree_probability_loss = (
                torch.stack(degree_probability_terms).mean()
                if degree_probability_terms
                else degree_logits.sum() * 0.0
            )
            degree_graphlet_total = (
                float(weights.get("graphlet_logit", 1.0)) * degree_logit_loss
                + float(weights.get("graphlet_probability", 0.25)) * degree_probability_loss
            )
            degree_summary_total = degree_spectral_total + degree_graphlet_total
            total = total + degree_summary_weight * degree_summary_total
            degree_metrics = {
                f"degree_summary_{key}": value
                for key, value in raw_degree_metrics.items()
                if key != "loss"
            }
            degree_metrics.update(
                {
                    "degree_summary_loss": float(degree_summary_total.detach().cpu()),
                    "degree_summary_spectral_loss": float(degree_spectral_total.detach().cpu()),
                    "degree_summary_graphlet_loss": float(degree_graphlet_total.detach().cpu()),
                    "degree_summary_graphlet_logit_loss": float(degree_logit_loss.detach().cpu()),
                    "degree_summary_graphlet_probability_loss": float(
                        degree_probability_loss.detach().cpu()
                    ),
                }
            )
        with torch.no_grad():
            normalized_logit_rmse = torch.sqrt(
                (((predicted_logits - target_logits).square()) * mask_weight).sum()
                / coordinate_count
            )
            logit_mae = (
                torch.abs(predicted_logits - target_logits) * mask_weight
            ).sum() / coordinate_count
        metrics = dict(metrics)
        metrics.update(
            {
                "loss": float(total.detach().cpu()),
                "spectral_component_loss": float(spectral_total.detach().cpu()),
                "graphlet_component_loss": float(graphlet_total.detach().cpu()),
                "graphlet_logit_loss": float(graphlet_logit_loss.detach().cpu()),
                "graphlet_probability_loss": float(graphlet_probability_loss.detach().cpu()),
                "graphlet_logit_rmse": float(normalized_logit_rmse.detach().cpu()),
                "graphlet_logit_mae": float(logit_mae.detach().cpu()),
                "graphlet_probability_mae": float(probability_mae.detach().cpu()),
            }
        )
        metrics.update(degree_metrics)
        return total, metrics

    def model_config(self) -> dict[str, Any]:
        config = super().model_config()
        config.update(
            {
                "graphlet_block_widths": list(self.graphlet_block_widths),
                "graphlet_dim": self.graphlet_dim,
                "graphlet_dropout": self.graphlet_dropout_p,
                "graphlet_logit_epsilon": self.graphlet_logit_epsilon,
                "degree_summary_enabled": self.degree_summary_enabled,
                "degree_summary_dim": self.degree_summary_dim,
                "degree_summary_layers": self.degree_summary_layers,
                "degree_summary_dropout": self.degree_summary_dropout_p,
            }
        )
        return config

def training_time_horizon_from_config(config: dict[str, Any] | None) -> int | None:
    """Return the horizon used to normalize the ``time`` feature during training.

    Deprecated compatibility helper for pre-v2 checkpoints.  V2 spectral
    models use normalized diffusion progress directly in [0, 1], independent of
    the generation rewiring budget.
    """

    trajectory = dict((config or {}).get("topology_trajectory", {}) or {})
    if "steps" not in trajectory:
        return None
    return max(int(trajectory["steps"]), 1)


def save_topology_spectral_checkpoint(
    model: TopologySpectralTransformerPredictor,
    path: str | Path,
    *,
    summary_config: SummaryConfig | None = None,
    config: dict[str, Any] | None = None,
    report: dict[str, Any] | None = None,
    training_time_horizon: int | None = None,
) -> None:
    path = Path(path)
    ensure_dir(path.parent)
    torch.save(
        {
            "format": TOPOLOGY_SPECTRAL_CHECKPOINT_FORMAT,
            "pipeline_mode": "topology",
            "guidance_mode": "spectral",
            "predictor_type": (
                "joint_degree_spectral_transformer"
                if getattr(model, "joint_degree_enabled", False) else "spectral_transformer"
            ),
            "joint_degree_enabled": bool(getattr(model, "joint_degree_enabled", False)),
            "model_state_dict": model.state_dict(),
            "model_config": model.model_config(),
            "summary_config": (
                dict(summary_config.__dict__) if summary_config is not None else {}
            ),
            # The denominator used for the `time` feature during training.
            # run_topology_grapher.py reuses this so that `topology_refiner.steps`
            # stays a pure compute knob instead of silently reparameterizing the
            # predictor input.
            "training_time_horizon": training_time_horizon,
            "time_parameterization": "normalized_diffusion_progress_0_source_1_clean",
            "config": config or {},
            "report": report or {},
        },
        path,
    )


def load_topology_spectral_checkpoint(
    path: str | Path,
    *,
    device: str | torch.device = "auto",
) -> tuple[
    TopologySpectralTransformerPredictor,
    SummaryConfig,
    dict[str, Any],
]:
    resolved_device = (
        resolve_torch_device(device) if isinstance(device, str) else device
    )
    checkpoint = torch.load(Path(path), map_location=resolved_device)
    if checkpoint.get("format") != TOPOLOGY_SPECTRAL_CHECKPOINT_FORMAT:
        raise ValueError(
            "Checkpoint is not a topology Spectral Transformer predictor "
            f"({TOPOLOGY_SPECTRAL_CHECKPOINT_FORMAT})."
        )
    model_config = dict(checkpoint.get("model_config", {}) or {})
    if "joint_degree_config" in model_config:
        # Lazy import avoids a circular dependency with the base predictor.
        from grapher.rewiring_mlp.generic.joint_degree_model import JointDegreeSpectralPredictor
        model = JointDegreeSpectralPredictor(**model_config).to(resolved_device)
    else:
        model = TopologySpectralTransformerPredictor(**model_config).to(resolved_device)
    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()
    summary_config = SummaryConfig.from_dict(
        checkpoint.get("summary_config", {}) or {}
    )
    return model, summary_config, checkpoint



def save_topology_spectral_graphlet_checkpoint(
    model: TopologySpectralGraphletTransformerPredictor,
    path: str | Path,
    *,
    graphlet_basis: TopologyGraphletBasis,
    summary_config: SummaryConfig | None = None,
    config: dict[str, Any] | None = None,
    report: dict[str, Any] | None = None,
    training_time_horizon: int | None = None,
) -> None:
    path = Path(path)
    ensure_dir(path.parent)
    if tuple(graphlet_basis.simplex_block_widths) != tuple(model.graphlet_block_widths):
        raise ValueError("Graphlet basis simplex widths do not match the joint predictor.")
    torch.save(
        {
            "format": TOPOLOGY_SPECTRAL_GRAPHLET_CHECKPOINT_FORMAT,
            "pipeline_mode": "topology",
            "guidance_mode": "spectral_graphlet",
            "predictor_type": "spectral_graphlet_transformer",
            "model_state_dict": model.state_dict(),
            "model_config": model.model_config(),
            "graphlet_basis": graphlet_basis.to_dict(),
            "summary_config": (
                dict(summary_config.__dict__) if summary_config is not None else {}
            ),
            "training_time_horizon": training_time_horizon,
            "time_parameterization": "normalized_diffusion_progress_0_source_1_clean",
            "config": config or {},
            "report": report or {},
        },
        path,
    )


def load_topology_spectral_graphlet_checkpoint(
    path: str | Path,
    *,
    device: str | torch.device = "auto",
) -> tuple[
    TopologySpectralGraphletTransformerPredictor,
    TopologyGraphletBasis,
    SummaryConfig,
    dict[str, Any],
]:
    resolved_device = resolve_torch_device(device) if isinstance(device, str) else device
    checkpoint = torch.load(Path(path), map_location=resolved_device)
    if checkpoint.get("format") != TOPOLOGY_SPECTRAL_GRAPHLET_CHECKPOINT_FORMAT:
        raise ValueError(
            "Checkpoint is not a topology spectral+graphlet predictor "
            f"({TOPOLOGY_SPECTRAL_GRAPHLET_CHECKPOINT_FORMAT})."
        )
    basis = TopologyGraphletBasis.from_dict(dict(checkpoint.get("graphlet_basis", {}) or {}))
    model = TopologySpectralGraphletTransformerPredictor(
        **dict(checkpoint.get("model_config", {}) or {})
    ).to(resolved_device)
    if tuple(model.graphlet_block_widths) != tuple(basis.simplex_block_widths):
        raise ValueError("Checkpoint graphlet model width does not match its stored basis.")
    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()
    summary_config = SummaryConfig.from_dict(checkpoint.get("summary_config", {}) or {})
    return model, basis, summary_config, checkpoint
