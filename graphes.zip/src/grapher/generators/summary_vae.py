class SummaryVAE(nn.Module):
    def __init__(self, input_dim, latent_dim, hidden_dim, head_dims):
        super().__init__()

        self.encoder = MLP(input_dim, hidden_dim)
        self.mu = nn.Linear(hidden_dim, latent_dim)
        self.logvar = nn.Linear(hidden_dim, latent_dim)

        self.decoder = MLP(latent_dim, hidden_dim)

        self.n_head = nn.Linear(hidden_dim, head_dims["num_nodes"])
        self.degree_head = nn.Linear(hidden_dim, head_dims["degree"])
        self.clustering_head = nn.Linear(hidden_dim, head_dims["clustering"])
        self.spectral_head = nn.Linear(hidden_dim, head_dims["spectral"])
        self.motif_head = nn.Linear(hidden_dim, head_dims["motif"])
        self.orbit_head = nn.Linear(hidden_dim, head_dims["orbit"])

    def encode(self, x):
        h = self.encoder(x)
        return self.mu(h), self.logvar(h)

    def decode(self, z):
        h = self.decoder(z)
        return {
            "num_nodes_logits": self.n_head(h),
            "degree_logits": self.degree_head(h),
            "clustering_logits": self.clustering_head(h),
            "spectral_logits": self.spectral_head(h),
            "motif_log": self.motif_head(h),
            "orbit_log": self.orbit_head(h),
        }

    def forward(self, x):
        mu, logvar = self.encode(x)
        z = reparameterize(mu, logvar)
        out = self.decode(z)
        return out, mu, logvar

    def sample(self, num_samples):
        z = torch.randn(num_samples, self.latent_dim)
        return self.decode(z)